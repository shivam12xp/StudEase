// Based on:
// https://codeforgeek.com/2014/09/handle-get-post-request-express-4/
var AWS = require('aws-sdk');
var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors'); // Allows for cross-domain requests (ie: from the client)

var peer = require('peer');

/**
 *	App initialization
 */

var app = express();
var server = require('http').createServer(app);
var port = process.env.PORT || 8080;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(cors({credentials: true, origin: true})); // TODO only allow whitelisted domains

AWS.config.region = process.env.REGION;

/**
 *	API Endpoints:
 */

apiNames = [
	'user'
];

for (apiName of apiNames) {
	require('./api/' + apiName + '.js')(app);
}

// PeerJS server
var options = {
    debug: true
}
app.use('/citrixapp', peer.ExpressPeerServer(server, options));

app.get('/', function(req, res) { res.send(port); });

/**
 *	Server entry point:
 */

server.listen(port,function(){
	console.log('Started server on port:' + port);
});

module.exports = app;