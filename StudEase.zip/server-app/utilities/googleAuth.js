var request = require('request');

const googleTokenVerifyURL = 'https://www.googleapis.com/oauth2/v3/tokeninfo?id_token=';
const date = new Date();

/**
 *	Validate the authenticity of a request before executing some logic
 *	@param req: the original http request
 *	@param callbackSuccess: function called upon successfully validating the tokens
 *	@param callbackFailure: function called upon failing to validate the tokens
 */
module.exports.verify = function(req, callbackSuccess, callbackFailure) {
	var id = req.headers.id;
	var id_token = req.headers.id_token;

	var url = googleTokenVerifyURL + id_token;

	// Validate the id_token and access_token using Google's API
	request({
	    url: url,
	    method: 'GET',
	}, function(error, response, body){
		body = JSON.parse(body);
	    if (error // Invalid tokens / tokens don't match / bad request
	    	|| !body.sub || body.sub !== id // User doesn't match token
	    	|| !body.iss || !body.iss.endsWith('google.com') // Not issued by google.com
	    	|| !body.exp || body.exp < date.getTime() / 1000 // Expired
	    	)
	    {
	    	console.log(body);
	    	callbackFailure();
	    } else {
	    	callbackSuccess();
	    }
	});
};
