var AWS = require('aws-sdk');
AWS.config.update({ 
    region: "us-west-2"
});

var docClient = new AWS.DynamoDB.DocumentClient();

var tableNameSuffix = process.env.NODE_ENV === 'production' ? '' : '-testing';
module.exports.tables = {
	users: 'users' + tableNameSuffix,
	groups: 'groups' + tableNameSuffix,
	classes: 'classes' + tableNameSuffix,
	schools: 'schools' + tableNameSuffix
}

/*	
 *	Returns all items from the given table which match the given key
 *
 *	@param table: 	 (string) name of DB table
 *	@param key: 	 (object) map of key -> value
 *	@param callback: function taking (err, data)
 */
module.exports.get = function(table, key, callback){
	var getParams = {
		TableName: table,
		Key: key
	};
	docClient.get(getParams, function(err, data) {
        callback(err, data.Item);
    });
};

/*	
 *	Batches multiple batches into one request
 *
 *	@param batches: (object) {
 *		@key table: {
 *			(list) [
 *				map of key -> value, ...
 *			]
 *		},
 *		...
 *	}
 *	@param callback: function taking (err, data)
 */
module.exports.getBatch = function(batches, callback){
	var getBatchParams = {};
	Object.keys(batches).forEach( function (key) {
		getBatchParams[key] = {
			Keys: batches[key]
		};
	});
	docClient.batchGet({RequestItems:getBatchParams}, function(err, data) {
        callback(err, data);
    });
};

/*	
 *	Returns all items from the given table which match the given indexed key
 *	
 *	Using indexed key is much faster, but requires that the DB already be
 *	indexed under the key provided. Add indices via the AWS console (be sure to
 *	use the default '-index' naming convention!!!)
 *
 *	@param table: 	 (string) name of DB table
 *	@param key
 *	@param value
 *	@param callback: function taking (err, data)
 */
module.exports.getIndexed = function(table, key, value, callback){
	var queryParams = {
		TableName: table,
		IndexName: key + '-index',
		KeyConditionExpression: key + '=:var',
		ExpressionAttributeValues: {
            ':var': value
        }
	};
	docClient.query(queryParams, function(err, data) {
        callback(err, data.Item);
    });
};

/*	
 *	Deletes all items from the given table which match the given key
 *
 *	@param table: 	 (string) name of DB table
 *	@param key: 	 (object) map of key -> value
 *	@param callback: function taking (err, data)
 */
module.exports.delete = function(table, key, callback){
	var deleteParams = {
		TableName: table,
		Key: key
	};
	docClient.delete(deleteParams, function(err, data) {
        callback(err, data);
    });
};

/*	
 *	Utility for chaining together updates.
 *	If an item matching the given key exists, update it with the given updates
 *	Otherwise, create it and apply the given updates
 *
 *	@param table: 	 (string) name of DB table
 *	@param key: 	 (object) map of key -> value (primary key, sorting key if required)
 *
 *	Example usage:
 *	db.startUpdate('users', { id: '123089123' })
 *		.set({ LastName: 'Werner', FavColor: 'Blue' })
 *		.addToList({ existingList: [4, 5, 6] })
 *		.addToList({ newList: ['foo', 'bar'] })
 *		.addToMap(mapName, { key: value, key2: value2 })
 *		.removeFromMap(mapName, [otherKey, otherKey2])
 *		.update(callback)
 *
 *  docs.aws.amazon.com/amazondynamodb/latest/developerguide/Expressions.Modifying.html#Expressions.Modifying.UpdateExpressions
 */
module.exports.startUpdate = function(table, key) {
	var varIndex = 0, // Used to generate unique expression attribute values
		nameIndex = 0, // Used to generate unique expression attribute names
		varMap = {}, // Maps variables to keys to update
		nameMap = {}, // Mapes names to keys to update
		updateExpressions = { // Stores current update expressions for each operation
			SET: '', DELETE: '', REMOVE: ''
		}

	var _getVar = function(value) {
		var varName = ':var' + varIndex;
		varIndex += 1;
		varMap[varName] = value;
		return varName;
	}

	var _getName = function(value) {
		var name = '#name' + nameIndex;
		nameIndex += 1;
		nameMap[name] = value;
		return name;
	}

	var _getEmpty = function() {
		varMap[':empty'] = [];
		return ':empty';
	}

	var _getObject = function() {
		return {
			set: set,
			update: update,
			addToList: addToList,
			addToMap: addToMap,
			removeFromMap: removeFromMap
		}
	}

	// @param updates: map of key->value updates
	var set = function(updates) {
		Object.keys(updates).forEach(function(key) {
			prefix = updateExpressions.SET.length > 0 ? ', ' : ' ';
			updateExpressions.SET += prefix + key + '=' + _getVar(updates[key]);
		});
		return _getObject();
	}

	// Append to an existing list or create a new list if it doesnt exist
	// @param additions: map of listName->[values] additions
	var addToList = function(additions) {
		Object.keys(additions).forEach(function(key) {
			prefix = updateExpressions.SET.length > 0 ? ', ' : ' ';
			updateExpressions.SET += prefix + key + '=list_append('
				+ 'if_not_exists(' + key + ',' + _getEmpty() + '),'
				+ _getVar(additions[key]) + ')';
		});
		return _getObject();
	}

	// @params mapName: name of the map to add to
	// @param additions: map of listName->value additions
	var addToMap = function(mapName, additions) {
		Object.keys(additions).forEach(function(key) {
			prefix = updateExpressions.SET.length > 0 ? ', ' : ' ';
			updateExpressions.SET += prefix + mapName + '.'
				+ _getName(key) + '=' + _getVar(additions[key]);
		});
		return _getObject();
	}

	// @params mapName: name of the map to remove from
	// @param removals: list of [values] to remove
	var removeFromMap = function(mapName, removals) {
		removals.forEach(function(removal) {
			prefix = updateExpressions.REMOVE.length > 0 ? ', ' : ' ';
			updateExpressions.REMOVE += prefix + mapName + '.' + _getName(removal);
		});
		return _getObject();
	}

	// @param callback: function taking (error, data)
	var update = function(callback) {
		var updateExpression = '';
		Object.keys(updateExpressions).forEach(function(op) {
			if (updateExpressions[op].length > 0) { 
				prefix = updateExpression.length > 0 ? ' ' : '';
				updateExpression += prefix + op + updateExpressions[op];
			}
		});
		var updateParams = {
			TableName: table,
			Key: key,
			UpdateExpression: updateExpression,
			ReturnValues: 'ALL_NEW'
		};
		if (varIndex > 0) { updateParams.ExpressionAttributeValues = varMap; }
		if (nameIndex > 0) { updateParams.ExpressionAttributeNames = nameMap; }
	    docClient.update(updateParams, function(err, data) {
	        callback(err, data.Attributes);
	    });
	}

	return _getObject();
};
