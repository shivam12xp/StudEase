var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
var ent = require('ent');
var fs = require('fs');


// loading the page chat.html
app.get('/', function(req, res) {
	res.send_file(__dirname + '/chat.html');
});

io.sockets.on('connection', function(socket, username) {
	
	// new user joins the chat
	socket.on('new_user', function(username) {
		username = ent.encode(username);
		socket.username = username;
		socket.broadcast.emit('new_user', username);
	});

	// message is received by server
	socket.on('message', function(message) {
		message = ent.encode(message);
		socket.broadcast.emit('message', {username: socket.username, message: message});
	});
})

server.listen(8080);