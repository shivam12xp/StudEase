var db = require('../utilities/db.js');
var auth = require('../utilities/googleAuth.js');

/*
 *	API endpoints for user data
 */

module.exports = function (app) {

	/**
	 *	Return basic user information
	 *	(accessible to anyone)
	 * 	Ex: GET user/10309123021
	 *  http://docs.aws.amazon.com/amazondynamodb/latest/APIReference/API_GetItem.html
	 */
	app.get('/user/:userId', function (req, res) {

		db.get(db.tables.users, { id: req.params.userId }, function(err, data) {
		    if (err) {
		        res.status(500).send(err);
		    } else {
		    	res.status(200).send(data);
		    }
		});
	});

	/**
	 *	Create a new user or update an existing user
	 *	(accessible only to user with id userId)
	 *	Ex: POST user/10309123020?firstname=peter&lastname=werner
	 */
	app.post('/user/:userId', function (req, res) {

		// Called if the userId matches and auth tokens are valid
		var callbackSuccess = function() {
			db.startUpdate(db.tables.users, { id: req.params.userId })
				.set(req.query)
				.update(function (err, data) {
				    if (err) {
				        res.status(500).send(err);
				    } else {
				    	res.status(200).send(data);
				    }
				});
		}

		// Called if the userId does not match or auth tokens are invalid
		var callbackFailure = function() {
			res.status(401).send();
		}

		if (req.params.userId !== req.headers.id) {
			callbackFailure();
		} else {
			auth.verify(req, callbackSuccess, callbackFailure);
		}
	});

}