// Install mocha to run the tests:
// 		sudo npm install -g mocha@2.3.1

// Each time you run the tests, update the test user (some tests require a fresh auth token)
//		Start the client-app locally, open the dev console, login with google,
//		Copy the object from the console and paste it into server-app/test/authed_test_user

var chai = require('chai');
var chaiHttp = require('chai-http');
var server = require('../server.js');
var should = chai.should();
var fs = require('fs');

chai.use(chaiHttp);

const authedUser = JSON.parse(fs.readFileSync(__dirname + '/authed_test_user'));

describe('User API', function() {

	// Login (after account already exists)
	it('GET user info from database', function(done) {
		const testUser = {
			id: 'test_user_id',
			test_field: 'foo'
		}
		chai.request(server)
			.get('/user/' + testUser.id) // Request URL
			.end(function (err, res) {
				res.should.have.status(200);
				var user = res.body;
				user.test_field.should.equal(testUser.test_field);
				user.id.should.equal(testUser.id);
				done();
			});
	});

	// Updating user info
	it('POST user info to database', function(done) {
		var randomNum = Math.random().toString();
		chai.request(server)
			.post('/user/' + authedUser.id) // Request URL
			.set('id', authedUser.id) // id header
			.set('id_token', authedUser.id_token) // id_token header
			.query({ random_number: randomNum }) // Params to update
			.end(function (err, res) {
				res.should.have.status(200);
				var user = res.body;
				user.random_number.should.equal(randomNum);
				user.id.should.equal(authedUser.id);
				done();
			});
	});

	// Adding new user to the database
	it('PUT new user into database', function(done) {
		chai.request(server)
			.put('/user/' + authedUser.id) // Request URL
			.set('id', authedUser.id) // id header
			.set('id_token', authedUser.id_token) // id_token header
			.end(function (err, res) {
				res.should.have.status(200);
				res.body.id.should.equal(authedUser.id);
				done();
			});
	});

});

describe('Group API', function() {

	// Create new study group
	it('PUT new group into database', function(done) {
		const testGroup = {
			displayName: '',
			invitedUserIds: []
		}
		chai.request(server)
			.put('/group') // Request URL
			.query(testGroup) // Params to put
			.end(function (err, res) {
				res.should.have.status(200);
				res.body.displayName.should.equal(testGroup.displayName);
				done();
			});
	});

	// Add users to study group
	it('POST group updates to database', function(done) {
		const testGroupID = 'TODO';
		const testGroup = {
			displayName: '',
			invite: [authedUser.id],
		}
		chai.request(server)
			.put('/group/' + testGroupID) // Request URL
			.query(testGroup) // Params to update
			.end(function (err, res) {
				res.should.have.status(200);
				res.body.users.should.include.keys(authedUser.id);
				done();
			});
	});

});