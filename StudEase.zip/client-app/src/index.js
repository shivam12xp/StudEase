import React from 'react';
import ReactDOM from 'react-dom';
import createBrowserHistory from 'history/lib/createBrowserHistory';
import { Router, Route, IndexRoute, Redirect, useRouterHistory } from 'react-router';

import chat from './utilities/firechat.js';

import BaseLayout from './layouts/BaseLayout.jsx';
import HomeLayout from './layouts/HomeLayout.jsx';
import DashboardLayout from './layouts/DashboardLayout.jsx';
import CreateSessionLayout from './layouts/CreateSessionLayout.jsx';
import SessionLayout from './layouts/SessionLayout.jsx';
import CourseLayout from './layouts/CourseLayout.jsx';

import '../public/css/index.css';

// Allows react routes to show up in the url bar of the browser
const appHistory = useRouterHistory(createBrowserHistory)({
	queryKey: false
});

// If the user is not logged in, redirects to login screen
function requireAuth(nextState, replace) {
	if (!chat.user) {
		replace({
			pathname: '/',
			state: { nextPathname: nextState.location.pathname }
		})
	}
}

function getDefaultPage() {
	return chat.user ? '/dashboard' : '/';
}

ReactDOM.render(
	<Router history={appHistory}>
		<Route path='/' component={ BaseLayout } >

			<IndexRoute component={ HomeLayout } />

			<Route path='dashboard' component={ DashboardLayout } onEnter={ requireAuth } />

			<Route path='create' component={ CreateSessionLayout } onEnter={ requireAuth } />

			<Route path='course/:courseId/session/:roomId' component={ SessionLayout } onEnter={ requireAuth } />

			<Route path='course/:courseId' component={ CourseLayout } onEnter={ requireAuth } />
			<Route path='course/:courseId/file/:fileId' component={ CourseLayout } onEnter={ requireAuth } />
			
			<Redirect from='*' to={ getDefaultPage() } />
		</Route>
	</Router>
	,
	document.getElementById('root')
);
