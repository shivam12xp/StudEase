import Draggable from 'react-draggable';
import React, { Component } from 'react';

import ResizeListenerComponent from './ResizeListenerComponent.jsx';

import '../../public/css/VertSlideComponent.css';

// Key for storing window size in local storage (remembered across sessions)
const preferredSizeKey = 'VertSlideComponent-preferredSize';

/*
 *	Takes exactly 2 child objects
 */
export default class VertSlideComponent extends Component {

	constructor(props, context) {
		if (!Array.isArray(props.children) || props.children.length !== 2) {
			throw new Error('VertSlideComponent requires exactly 2 children');
		}
		super(props, context);
		this.state = {
			dimensions: {
				w: 0, h: 0
			},
			deltaPosition: {
				x: 0, y: 0
			}
		};
	}

	onResize = (dimensions) => {
		this.yChange = dimensions.h / this.state.dimensions.h;
		if (isNaN(this.yChange) || this.yChange === Infinity) {
			this.yChange = 1;
		}
		var { x, y } = this.state.deltaPosition;
		this.setState({
			dimensions: dimensions,
			deltaPosition: {
				y: y * this.yChange,
				x: x
			}
		});
		this.refs.draggable.setState({
			y: this.refs.draggable.state.y * this.yChange
		});
		if (this.onFirstNonzeroResize && dimensions.w && dimensions.h) {
			this.onFirstNonzeroResize(dimensions);
			this.onFirstNonzeroResize = null;
		}
	}

	// Called the first time a resize occurs where the dimensions are non-0
	onFirstNonzeroResize = (dimensions) => {
		var posNormalized = parseFloat(localStorage.getItem(preferredSizeKey + this.props.prefId)) || this.props.default;
		if (posNormalized > 0.5 || posNormalized < -0.5) {
			posNormalized = 0;
		};
		this.setState({
			deltaPosition: {
				y: posNormalized * dimensions.h,
				x: this.state.deltaPosition.x
			}
		});
		this.refs.draggable.setState({
			y: posNormalized * dimensions.h
		});
	}

	componentWillUnmount() {
		var posNormalized = this.state.deltaPosition.y / this.state.dimensions.h;
		localStorage.setItem(preferredSizeKey + this.props.prefId, posNormalized);
	}

	handleDrag = (e, ui) => {
		var { x, y } = this.state.deltaPosition;
		this.setState({
			deltaPosition: {
				x: x + (ui.deltaX || 0),
				y: y + (ui.deltaY || 0)
			}
		});
	}

	onStart = () => {
		this.setState({
			active: true
		});
	}

	onStop = () => {
		this.setState({ active: false });
	}

	render() {

		const dragHandlers = {onStart: this.onStart, onStop: this.onStop};

		var sizeTopPane = 0.5 * this.state.dimensions.h + this.state.deltaPosition.y;
		var sizeBotPane = this.state.dimensions.h - sizeTopPane;

		var sliderClassName = 'vert-slide-slider' + (this.state.active ? ' active' :'');

		// Coverup is enabled when the slider is being dragged around,
		//  	blocking mouse events in the left and right panes
		return (
			<ResizeListenerComponent callback={ this.onResize }>
				<div className='vert-slide-container resize-listener-child'>

					<div className='vert-slide-pane' style={{ flex: sizeTopPane }}>
						{ this.props.children[0] }
					</div>

					<Draggable bounds='parent' axis='y' onDrag={ this.handleDrag } {...dragHandlers} ref='draggable'>
						<div className={ sliderClassName } ref='slider'>
							<div className='vert-slide-slider-handle'/>
						</div>
					</Draggable>

					<div className='vert-slide-pane vert-slide-pane-bottom' style={{ flex: sizeBotPane }}>
						{ this.props.children[1] }
					</div>

					<div className={ 'vert-slide-coverup' + (this.state.active ? '' : ' hidden') }/>

				</div>
			</ResizeListenerComponent>
		);
	}

}