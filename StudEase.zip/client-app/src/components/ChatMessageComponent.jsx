import React, { Component } from 'react';
import Firebase from '../utilities/firebase.js';

import '../../public/css/ChatMessageComponent.css';

/**
 *	Renders the user's name and profile image along with the message
 */
export default class ChatMessageComponent extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {};
	}

	componentWillMount () {
		var self = this;
		Firebase.getPhoto(this.props.message.userId, function(err,data) {
			if (!err && data) {
				self.setState({ photoUrl: data });
			}
		});
	}

	render() {

		// Display placeholder user image while waiting for real image to be retrieved
		var imageClass = 'chat-message-image';
		var defaultUrl = 'http://sportstradinglife.com/wp-content/uploads/2015/08/tipster-interview.jpg'; // TODO
		var userImage = (
			<img className={ imageClass } src={ this.state.photoUrl || defaultUrl } role='presentation' />
		);
		return (
			<div className='chat-message'>
				<div className='chat-message-image-container'>
					{ userImage }
				</div>
				<div className='chat-message-content-container'>
					<div className='chat-message-name'>
						{ this.props.message.name }
					</div>
					<div className='chat-message-content'>
						{ this.props.message.message }
					</div>
				</div>
			</div>
		);
	}

}