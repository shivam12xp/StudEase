import React, { Component } from 'react';
import Firebase from '../utilities/firebase.js';
import Metadata from '../utilities/metadata.js';
import '../../public/css/CourseDashComponent.css';

import SessionListComponent from '../components/SessionListComponent.jsx';
import FileListComponent from '../components/FileListComponent.jsx';

class CourseDashComponent extends Component {

	constructor (props, context) {
		super(props, context);
		this.state = {
			numUsersOnline: 0,
			numSessionsActive: 0,
			numFiles: 0,
			newFiles: {},
		}
	}
	 componentWillMount(){
            var self = this;
            Firebase.getClassActives(self.props.courseId, function(err, actives){
               if(!err){
                   self.setState({
                       numUsersOnline: actives.length
                   });
               }else{
                   self.setState({
                   numUsersOnline: 0
               });
               }
            });
            
            Firebase.getClassFiles(self.props.courseId, function(err, files){
               if(!err){
                   self.setState({
                       numFiles: files.length
                   });
		       
		       files.forEach((file, index) => {
                       Metadata.getFileMetadata(file, function(err, data) {
                            if (!err && data) {
                                    var date = new Date(data.modified);
                                    var today = new Date();
                                    if((date.getDate()) === (today.getDate())){
                                    	self.state.newFiles[file] = true;
                                        self.setState({});
                                    }
                            }
                    });
                   });
               }else{
                   self.setState({
                   numFiles: 0
               });
               }
            });
		 
             Firebase.getSessionsFromClass(self.props.courseId, function(err, sessions){
               if(!err){
                   sessions.forEach((session, index)=> {
                       
                        
                       Firebase.getSessActives(session, function(err, actives){
                           if(!err){
                            if(actives.length > 0){
                                self.setState({
                                  numSessionsActive: (self.state.numSessionsActive + 1) 
                               });
                            }
                           }
                       });
                       
                   });
                   
               }else{
                   console.log("Error");
               }
            });
        }
	onFileSelected = (file) => {
		this.context.router.push('/course/' + this.props.courseId + '/file/' + file.id);
	}


	onSessionSelected = (sessId) => {
        console.log("sessID" + sessId);
        this.context.router.push('/course/' + this.props.courseId + '/session/' + sessId);
           
    }

    onCourseSelected = () => {
 		this.context.router.push('/course/' + this.props.courseId);
 	}


	// TODO button to open course page

	// TODO maybe limit summary length...

	// TODO hide session button for sessionlist like we hide search/picker for filelist

	// TODO show X files, X new files above files list

	// TODO show X users online, X sessions active above sessions list

	render() {
		return (
			<div className='course-dash'>

				<div className='course-dash-summary'>
					<div className='course-summary-info'>
						<h2 className='course-summary-info-title'>
							{ this.props.course.title }
						</h2>
						<div className='course-summary-info-description'>
							{ this.props.course.description }
						</div>
					</div>
				</div>

				<div className='course-dash-highlights'>
					<div className='course-dash-highlight a'>
						<div className='course-dash-highlight-number'>
							{ Object.keys(this.state.newFiles).length }
						</div>
						<div className='course-dash-highlight-label'>
							new files
						</div>
					</div>
					<div className='course-dash-highlight b'>
						<div className='course-dash-highlight-number'>
							{ this.state.numFiles }
						</div>
						<div className='course-dash-highlight-label'>
							total files
						</div>
					</div>
				</div>

				<div className='course-dash-files'>
					<FileListComponent courseId={ this.props.courseId }
						roomId={'-KVhUUhx-NWqQ-3CFM91'}
						onFileSelected={ this.onFileSelected }
						hidePicker={ true }
						hideSearch={ true }
						hideTags={ true }
						inCourse ={true}
					/>
				</div>

				<div className='course-dash-highlights'>
					<div className='course-dash-highlight b'>
						<div className='course-dash-highlight-number'>
							{ this.state.numUsersOnline }
						</div>
						<div className='course-dash-highlight-label'>
							users online
						</div>
					</div>
					<div className='course-dash-highlight a'>
						<div className='course-dash-highlight-number'>
							{ this.state.numSessionsActive }
						</div>
						<div className='course-dash-highlight-label'>
							active sessions
						</div>
					</div>
				</div>

				<div className='course-dash-sessions'>
					<SessionListComponent courseId={ this.props.courseId }
						onSessionSelected={ this.onSessionSelected }
						hideAddButton={ true }
					/>
				</div>

				<div className='big-card-footer'>
					<button className='btn simplebutton goto-course-button' onClick={ this.onCourseSelected }>
						Enter Class
					</button>
				</div>
	
			</div>
		);
	}

}

CourseDashComponent.contextTypes = {
	router: React.PropTypes.object
};

export default CourseDashComponent;
