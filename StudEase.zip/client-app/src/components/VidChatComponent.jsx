import React, { Component } from 'react';

import ResizeListenerComponent from './ResizeListenerComponent.jsx';
import VideoComponent from './VideoComponent.jsx';

import PeerVideo from '../utilities/peerVideo.js';
import chat from '../utilities/firechat.js';
import Firebase from '../utilities/firebase.js';

import '../../public/css/VidChatComponent.css';

/*
 * 	Props:
 *	- roomId: firechat room id
 */
export default class VidChatComponent extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {
			userIds: [],		// All users in the room
			users: [],			// Metadata of all users in the room
			streams: {}, 		// Video streams (with subset of users)
			aspectLastUpdate: 1 // Aspect ratio last time we rendered
		};
		this.domNode = null;
		this.dimensions = { w:1, h:1 };
	}

	componentWillMount() {
		var self = this;
		PeerVideo.initUserMedia(function(stream) {
			self.onUsersUpdate([]);
			PeerVideo.mountListener(self.props.roomId, self);
			// Add local user's stream
			var streams = self.state.streams;
			streams[chat.user.id] = URL.createObjectURL(stream);
			self.setState({ streams: streams });
		});
	}

	componentWillUnmount() {
		PeerVideo.unmountListener(this.props.roomId, this);
	}

	onStreamOpen(userId, stream) {
		if (this.state.userIds.includes(userId)) {
			var streams = this.state.streams;
			streams[userId] = URL.createObjectURL(stream);
			this.setState({ streams: streams });
		}
	}

	onStreamClose(userId) {
		var streams = this.state.streams;
		delete streams[userId];
		this.setState({
			streams: streams
		});
	}

	onUsersUpdate(userIds) {
		var self = this;
		userIds.forEach(function(userId) {
			if(!self.state.userIds.includes(userId)) {
				PeerVideo.call(userId);
			}
			var users = self.state.users;
			users[userId] = {id : userId};
			self.setState({ users: users });
		});
		self.setState({ userIds: userIds });
	}

	onResize = (dimensions) => {
		this.dimensions = dimensions;
		var aspectNow = dimensions.w / dimensions.h;
		// Rerender if aspect ratio has changed significantly
		if (Math.abs(this.state.aspectLastUpdate - aspectNow) > 0.1) {
			this.setState({ aspectLastUpdate: aspectNow });
		}
	}

	getVideoComponentsFormatted() {
		var videos = this.getVideoComponents(),
			dim = this.dimensions,
			numRows = Math.min(
				videos.length,
				Math.ceil((Math.sqrt(videos.length) * dim.h / dim.w))
			);
		var rows = [];
		for (var i = 0; i < numRows; i++) {
			rows.push([]);
		}
		for (var j = videos.length - 1; j >= 0; j--) {
			var rowIndex = numRows - 1 - (j % numRows);
			rows[rowIndex].unshift(videos[j]);
		}
		return rows.map(function(row, index) {
			return (
				<div className='vidchat-row' key={ index }>
					{ row }
				</div>
			)
		});
	}

	getVideoComponents() {
		var self = this,
			ids = Object.keys(self.state.streams),
			localUser = chat.user.id;
		if (self.state.streams[localUser]) {
			ids.push(ids.splice(ids.indexOf(localUser),1)[0]); // Put localUser at the end
		}
		return ids.map(function(id) {
			return (
				<VideoComponent
					key={ id }
					stream={ self.state.streams[id] }
					user={ self.state.users[id] }
				/>
			);
		});
	}

	// Renders the component upon each change of state
	render() {
		return (
			<ResizeListenerComponent callback={ this.onResize }>
				<div className='vidchat resize-listener-child'>
					{ this.getVideoComponentsFormatted() }
				</div>
			</ResizeListenerComponent>
		);
	}

}

