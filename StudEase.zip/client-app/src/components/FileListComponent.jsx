import React, { Component } from 'react';
import FileComponent from './FileComponent.jsx';
import BaseLayout from '../layouts/BaseLayout.jsx';
import ResizeListenerComponent from './ResizeListenerComponent.jsx';
import Metadata from '../utilities/metadata.js';
import Firebase from '../utilities/firebase.js';
import Firebase2 from '../utilities/firebase2.js';
import searchScore from '../utilities/search.js';
import Server from '../utilities/server.js';
import FileCache from '../utilities/filecache.js';
import chat from '../utilities/firechat.js'
import GooglePicker from '../utilities/googlePicker.js';
import drive from '../../public/drive.png';

import '../../public/css/FileListComponent.css';



/**
 *	Props:
 *	-	courseId
 *	-	roomId (if not specified, all rooms in class)
 *  -   onFileSelected (function)
 *  -   currentFile
 */

export default class FileListComponent extends Component {
	
	constructor(props, context) {
		super(props, context);
		this.state = {
			courseFiles: {}, // map of fileId -> file objects
			roomFiles: {}, // map of fileId -> file objects
			searchString: '',
			sortedSearchedFiles: [], // array of file objects
			sessionFilesOnly: this.props.sessionChecked,
			starredFilesOnly: this.props.starredFilesChecked,
			numColumns: 1
		};
	}

	componentWillMount() {
		if (this.props.roomId) {
			var self = this;
			[1, 10, 100, 500, 1000].forEach(function(t){
				setTimeout(function(){
					if (Object.keys(self.state.roomFiles).length <= 0) {
						FileCache.startListeningSession(
							self.props.roomId,
							'session' + self.props.roomId,
							self.onSessionFilesChanged
						);
					}
				}, t);
			});
		}
		if (this.props.courseId) {
			FileCache.startListeningCourse(this.props.courseId, 'course' + this.props.courseId, this.onCourseFilesChanged);
		}
		var self = this;
		// self.setState({ sessionFilesOnly: self.props.sessionChecked });
		 if(this.props.inCourse){
                 self.setState({
                     sessionFilesOnly: false
                 });
             }else{
                 self.setState({
                     sessionFilesOnly: self.props.sessionChecked,
                     starredFilesOnly: self.props.starredFilesChecked
                 });
             }
		/*
		if (this.props.roomId) {
			Firebase2.listenToSessionFiles({ sessionId: this.props.roomId }, this.onSessionFilesChanged);
		}
		if (this.props.courseId) {
			Firebase2.listenToClassFiles({ courseId: this.props.courseId }, this.onCourseFilesChanged);
		}
		*/
	}

	componentDidMount() {
		this.fileIdOverride = this.props.initialFileId;
		this.search(this.state.searchString, this.state.sessionFilesOnly, this.state.starredFilesOnly);
	}

	componentWillUnmount() {
		if (this.props.roomId) {
			FileCache.stopListeningSession(this.props.roomId, 'session' + this.props.roomId);
		}
		if (this.props.courseId) {
			FileCache.stopListeningCourse(this.props.courseId, 'course' + this.props.courseId);
		}
	}

	onCourseFilesChanged = (files) => {
		this.state.courseFiles = files;
		// console.log("FILEZ",files);
		this.setState({});
		this.search(this.state.searchString, this.state.sessionFilesOnly, this.state.starredFilesOnly);
	}

	onSessionFilesChanged = (files) => {
		this.state.roomFiles = files;
		this.setState({});
		this.search(this.state.searchString, this.state.sessionFilesOnly, this.state.starredFilesOnly);
	}

	handleFileOverride = () => {
		// console.log("RAN FUNCTION", this.props.fileOverrideId);
		if (this.props.fileOverrideId) {
			var files = this.state.sortedSearchedFiles;
			var self = this;
			files.forEach((file, index) => {
				if (file.id === self.props.fileOverrideId) {
					self.props.onFileSelected(file);
				}
			});
		}
	}


	addFile(data){
		var self = this;
		var callback = function (file) {
			self.search(self.state.searchString, self.state.sessionFilesOnly, self.state.starredFilesOnly);
		}
		for(var i = 0; i<data.docs.length; i++) {
			var doc = data.docs[i];
			Firebase2.updateFile({
				fileId: doc.id,
				courseId: self.props.courseId,
				sessionId: self.props.roomId
			});
		}
	}


	search (searchString, sessionFilesOnly, starredFilesOnly) {
		// console.log('SEARCH',searchString, sessionFilesOnly, starredFilesOnly);
		var filesObj = sessionFilesOnly ? this.state.roomFiles : this.state.courseFiles;
		var filesArray = Object.values(filesObj).filter((o) => !!o);
		var userId = chat.user.id;
		if (starredFilesOnly) {
			filesArray = filesArray.filter((f) => (f.upvoters || {})[userId]);
		}
		if (!searchString || searchString.length <= 0) {
			this.setState({
				sortedSearchedFiles: filesArray.sort((a, b) => b.upvotes - a.upvotes)
			});
		} else {
			searchScore.assignSearchValue(filesArray, searchString);
			this.setState({
				sortedSearchedFiles: filesArray.filter((o) => o.score > 0).sort((a, b) => b.score - a.score)
			});
		}
		this.handleFileOverride();
	}


	handleChange = (event) => {
		this.setState({
			searchString: event.target.value
		});
		this.search (event.target.value, this.state.sessionFilesOnly, this.state.starredFilesOnly);
		this.handleFileOverride ();
	}

	handleClear = (event) => {
		this.setState({
			searchString: ''
		});
		this.search ('', this.state.sessionFilesOnly, this.state.starredFilesOnly);
	}

	handleSubmit = (event) => {
		event.preventDefault();
		return false;
	}

	handleSessionOnlyCheckboxChange = (event) => {
		var newVal = !this.state.sessionFilesOnly;
		this.setState({
			sessionFilesOnly: newVal
		});
		this.props.onSessionCheckboxChange(newVal);
		this.search (this.state.searchString, newVal, this.state.starredFilesOnly);
	}

	handleStarredOnlyCheckboxChange = (event) => {
		var newVal = !this.state.starredFilesOnly;
		this.setState({
			starredFilesOnly: newVal
		});
		this.props.onStarredFilesCheckboxChange(newVal);
		this.search (this.state.searchString, this.state.sessionFilesOnly, newVal);
	}

	onFileUpvote(file) {
		// console.log(file);
		// console.log('old upvotes: ' + file.upvotes);
		Firebase.toggleUpvote(file.id, () => {});
		// console.log('new upvotes: ' + file.upvotes);
	}


	onResize = (dimensions) => {
		// console.log(dimensions.w);
		var minWidth = 250;
		this.setState({
			numColumns: Math.max(1, Math.floor(dimensions.w / minWidth))
		});
	}

	getFileComponents = () => {
		// split list into smaller lists of size numColumns
		var allFiles = this.files.concat([]);
		var rows = [];
		while (allFiles.length > 0) {
			rows.push(allFiles.splice(0, this.state.numColumns));
		}
		var self = this;
		var allFileTags = {};
		return rows.map((row, index) => {
			while (row.length < rows[0].length) {
				row.push(null);
			}
			row.map((file, index) => {
				if (file) {
					Object.assign(allFileTags, file.tags);
				}
			});
			return (
				<div className='file-info-row'>
				{
					row.map((file, index) => {
						if (file) {		
							if(self.props.currentFile === file.id){
								return (
									<FileComponent key={index}
										file={ file }
										onSelect={ () => { self.props.onFileSelected(file) } }
										onUpvote={ () => self.onFileUpvote(file) }
										currentFile={ true }
										hideTags={ self.props.hideTags }
										allTags={ allFileTags }
									/>
								);
							} else{
								return (
									<FileComponent key={index}
										file={ file }
										onSelect={ () => { self.props.onFileSelected(file) } }
										onUpvote={ () => self.onFileUpvote(file) }
										currentFile={ false }
										hideTags={ self.props.hideTags }
										allTags={ allFileTags }
									/>
								);	
							}

						} else {
							return (
								<div className='file-info-spacer'/>
							);
						}
					})
				}
				</div>
			);
			
		});
	}

	
	render() {
		var self = this;
		var buttonClass = "simpleform-button fa fa-times";
		if (!this.state.searchString || this.state.searchString.length <= 0) {
			buttonClass += " hidden";
		}
		var files = this.state.sortedSearchedFiles;
		this.files = files;

		var showSessionFilesOnlyOption = !!this.props.roomId;
		var showSearchOptions = showSessionFilesOnlyOption;


		var imageClass = 'file-icon';
		var fileIcon = (
			<img className={ imageClass } src={drive} role='presentation' />
		);

		return (
			<div className='files'>

				<div className={'file-search-container' + (this.props.hideSearch ? ' hidden' : '') }>
					<form className="simpleform file-search-form" onSubmit={this.handleSubmit}> 
						<input className='input-box'
							type="text"
							value={this.state.searchString}
							placeholder="&#xf002; Search files and tags..."
							onChange={this.handleChange} />
						<i className={ buttonClass } onClick={this.handleClear} aria-hidden="true"></i>
					</form>
					<form className={ 'file-search-options' + (showSearchOptions ? '' : ' hidden') } onSubmit={this.handleSubmit}>
						<div className={ 'file-search-option' }>
							<input
								name="starredFilesOnlyCheckbox"
								type="checkbox"
								checked={this.state.starredFilesOnly}
								onChange={this.handleStarredOnlyCheckboxChange} />
							<span className='file-search-options-label'>Starred Files Only</span>
						</div>
						<div className={ 'file-search-option' + (showSessionFilesOnlyOption ? '' : ' hidden') }>
							<input
								name="sessionFilesOnlyCheckbox"
								type="checkbox"
								checked={this.state.sessionFilesOnly}
								onChange={this.handleSessionOnlyCheckboxChange} />
							<span className='file-search-options-label'>Session Files Only</span>
						</div>
					</form>

				</div>

				<div className='file-container'>
					<ResizeListenerComponent callback={ this.onResize }>
						<div className='resize-listener-child'>
							{ this.getFileComponents() }
						</div>
					</ResizeListenerComponent>
				</div>


				<div className={ 'big-card-footer' + (this.props.hidePicker ? ' hidden' : '') }>
					<div className='picker'>
						<GooglePicker clientId={'827618240582-ldef2fo3a0te9g9fiqfco4pkt6apc21o.apps.googleusercontent.com'}
							  developerKey={'AIzaSyAcX2UAdu4thKqKaS9UuuqIlnXNe9IAaW4'}
							  scope={['https://www.googleapis.com/auth/drive']}
							  onChange={data => {this.addFile(data)}}   //console.log('on change:', data)}
							  multiselect={true}
							  navHidden={true}
							  authImmediate={false}
							  viewId={'DOCS'}
							  origin={Server.getClientUrl()}
							  googleoauthtoken={Firebase.getOAuth()}>
							<button className='btn simplebutton'>
								Import from Drive
							</button>     
						</GooglePicker>   
					</div>
				</div>

			</div>
		);
	}

}
