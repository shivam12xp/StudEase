import React, { Component } from 'react';

import '../../public/css/FileFrameComponent.css';

/**
 *	Props:
 *	- 	fileId
 */
export default class FileFrameComponent extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {};
	}

	componentWillMount() {
		// TODO connect to Google Drive rather than hardcode the url!!!
		//var fileUrl = 'https://docs.google.com/document/d/1EzA-uaO9g_Yy2-yjUv2J_mNhkfNIrNhnISAYXh9MECE/edit';
		this.setState({
			url: this.props.fileId,
			frame: this.getFrameFromUrl(this.props.fileId)
		});
		console.log('componentWillMount FileFrame');
		console.log(this.getFrameFromUrl(this.props.fileId));
	}

	componentWillReceiveProps(nextProps){
		//console.log('start componentWillReceiveProps');
		this.setState({
			url: nextProps.fileId,
			frame: this.getFrameFromUrl(nextProps.fileId),
			frameLoaded: false
		});
		//console.log('end componentWillReceiveProps');
	}

	onFrameLoaded = () => {
		//console.log('start onFrameLoaded');
		if (this.state.frameLoaded) {
			// If the frame has been loaded twice, this probably means the user clicked into another url
			// Reload the frame so they can't escape
			this.setState({
				frame: this.getFrameFromUrl(this.state.url),
				frameLoaded: false
			});
		} else {
			this.setState({ frameLoaded: true });
		}
		//console.log('exit onFrameLoaded');
	}

	getFrameFromUrl = (url) => {
		//console.log('start getFrame');
		return (
			<iframe className='file-frame'
				// &ui=2 - (required for rm=demo) renders the spreadsheet in the 'new' version interface (note &ui=1 renders the 'old' version interface).
				// &chrome=false - renders the spreadsheet in full screen mode, i.e. without menu, controls (button bar) or formula bar
				// &rm=demo - renders the spreadsheet without the sheet menu, i.e. only one sheet (by default the first of a spreadsheet) is rendered
				src={ url + '?hl=en&ui=2&chrome=false&rm=demo' }
				onLoad={ this.onFrameLoaded }
				key={ Math.random() /* Randomize key so react reloads the src url */ }
			/>
		);
		//console.log('exit getFrame');
	}

	getError = () => {
		return (
			<div className='file-frame'>
				Error: TODO
			</div>
		);
	}

	getLoadingIcon = () => {
		return (
			<div className='file-frame'>
				<div className='loading-icon-container'>
					<div className='loading-icon'>
						<i className="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
						<span className="sr-only">Loading...</span>
					</div>
				</div>
			</div>
		);
	}

	render() {
		if (this.state.error) {
			return this.state.error;
		} else {
			var loaded = this.state.frame && this.state.frameLoaded;
			return (
				<div className={ 'file-frame' }>
					<div className={ 'file-frame' + (loaded ? '' : ' hidden') }>
						{ this.state.frame }
					</div>
					<div className={ 'file-frame' + (loaded ? ' hidden' : '') }>
						{ this.getLoadingIcon() }
					</div>
				</div>
			);
		}
		
	}

}