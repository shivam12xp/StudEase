import Draggable from 'react-draggable';
import React, { Component } from 'react';

import ResizeListenerComponent from './ResizeListenerComponent.jsx';

import '../../public/css/HorzSlideComponent.css';

// Key for storing window size in local storage (remembered across sessions)
const preferredSizeKey = 'HorzSlideComponent-preferredSize';

/*
 *	Takes exactly 2 child objects
 */
export default class HorzSlideComponent extends Component {

	constructor(props, context) {
		if (!Array.isArray(props.children) || props.children.length !== 2) {
			throw new Error('HorzSlideComponent requires exactly 2 children');
		}
		super(props, context);
		this.state = {
			dimensions: {
				w: 0, h: 0
			},
			deltaPosition: {
				x: 0, y: 0
			}
		};
	}

	onResize = (dimensions) => {
		this.xChange = dimensions.w / this.state.dimensions.w;
		if (isNaN(this.xChange) || this.xChange === Infinity) {
			this.xChange = 1;
		}
		var { x, y } = this.state.deltaPosition;
		this.setState({
			dimensions: dimensions,
			deltaPosition: {
				x: x * this.xChange,
				y: y
			}
		});
		this.refs.draggable.setState({
			x: this.refs.draggable.state.x * this.xChange
		});
		if (this.onFirstNonzeroResize && dimensions.w && dimensions.h) {
			this.onFirstNonzeroResize(dimensions);
			this.onFirstNonzeroResize = null;
		}
	}

	// Called the first time a resize occurs where the dimensions are non-0
	onFirstNonzeroResize = (dimensions) => {
		var posNormalized = parseFloat(localStorage.getItem(preferredSizeKey + this.props.prefId)) || this.props.default;
		if (posNormalized > 0.5 || posNormalized < -0.5) {
			posNormalized = 0;
		};
		this.setState({
			deltaPosition: {
				x: posNormalized * dimensions.w,
				y: this.state.deltaPosition.y
			}
		});
		this.refs.draggable.setState({
			x: posNormalized * dimensions.w
		});
	}

	componentWillUnmount() {
		var posNormalized = this.state.deltaPosition.x / this.state.dimensions.w;
		localStorage.setItem(preferredSizeKey + this.props.prefId, posNormalized);
	}

	handleDrag = (e, ui) => {
		var { x, y } = this.state.deltaPosition;
		this.setState({
			deltaPosition: {
				x: x + (ui.deltaX || 0),
				y: y + (ui.deltaY || 0)
			}
		});
	}

	onStart = () => {
		this.setState({
			active: true
		});
	}

	onStop = () => {
		this.setState({ active: false });
	}

	render() {

		const dragHandlers = {onStart: this.onStart, onStop: this.onStop};

		var sizeLeftPane = 0.5 * this.state.dimensions.w + this.state.deltaPosition.x;
		var sizeRightPane = this.state.dimensions.w - sizeLeftPane;

		var sliderClassName = 'horz-slide-slider' + (this.state.active ? ' active' :'');

		// Coverup is enabled when the slider is being dragged around,
		//  	blocking mouse events in the left and right panes
		return (
			<ResizeListenerComponent callback={ this.onResize }>
				<div className='horz-slide-container resize-listener-child'>

					<div className='horz-slide-pane' style={{ flex: sizeLeftPane }}>
						{ this.props.children[0] }
					</div>

					<Draggable bounds='parent' axis='x' onDrag={ this.handleDrag } {...dragHandlers} ref='draggable'>
						<div className={ sliderClassName } ref='slider'>
							<div className='horz-slide-slider-handle'/>
						</div>
					</Draggable>

					<div className='horz-slide-pane' style={{ flex: sizeRightPane }}>
						{ this.props.children[1] }
					</div>

					<div className={ 'horz-slide-coverup' + (this.state.active ? '' : ' hidden') }/>

				</div>
			</ResizeListenerComponent>
		);
	}

}