import React, { Component } from 'react';
import groupmsg from '../../public/groupmsg3.png';

import '../../public/css/SessionComponent.css';

/**
 *	Props:
 *	-	session id
 *	-	session name
 */
export default class SessionComponent extends Component {

	render() {
		var self = this;

		var sessionIcon = (
			<img className='session-icon' src={ groupmsg } role='presentation' />
		);

		return (
			<div className='session-info' onClick={ self.props.onSelect }>
				<div className='session-info-primary'>
					<div className='session-icon-container'>
						{ sessionIcon }
					</div>
					<div className='session-content-container'>
						<div className='session-name'>
							{ self.props.name }
						</div>
						<div className='session-meta'>
							<span className='file-session-content'>{ (self.props.onlineUsers || 0) + ' online users' }</span>
						</div>
					</div>
				</div>
			</div>
		);
	}

}
