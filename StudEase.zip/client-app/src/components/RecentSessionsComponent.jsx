import React, { Component } from 'react';
import { Link } from 'react-router';
import searchScore from '../utilities/search.js';
import Firebase from '../utilities/firebase.js';
import chat from '../utilities/firechat.js';
import SessComponent from '../components/SessComponent.jsx';

import '../../public/css/RecentSessionsComponent.css';


export default class RecentSessionsListComponent extends Component {
        
        //Constructor
        constructor(props, context) {
		super(props, context);
                this.state = {
                    RecentSessList: [],
                };
	}
        
        componentWillMount(){
                var self = this;
                
                Firebase.getSessionsInUser(chat.user.id, function(err, UserItems){
                    if(!err){
                        //get a list of sessions that are linked to the class
                        self.getRecentList(UserItems);  
                    } else{
                        self.setState({
                            RecentSessList: <button type="button" class="list-group-item list-group-item-action disabled">No Sessions...</button>
                        });
                    }
                });
                
                
                    
        }
        
        getRecentList(userlist){
            var self = this;
            Firebase.getSessionsFromClass(self.props.courseId, function(err, SessItems){
                    if(!err){
                        //self.goThrough(userlist, SessItems);
                        userlist.forEach(function(SessId){
                            if(SessItems.includes( SessId)){
                                self.state.RecentSessList.push(
                                    <SessComponent sessId={ SessId }/>
                                );
                            }
                          }  
                        );
                    }else{
                        self.state.RecentSessList.push(<button type="button" class="list-group-item list-group-item-action disabled">No Sessions...</button>);
                    }
                });
                
        }
        
        //render
        render(){
            var self = this;
            
            return(
                        <div className = 'Sess-List'>
                            {self.state.RecentSessList}
                        </div>
            )
        }
}
