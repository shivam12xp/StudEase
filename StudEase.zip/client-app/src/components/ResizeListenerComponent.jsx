import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ResizeSensor from 'css-element-queries/src/ResizeSensor';

import '../../public/css/ResizeListenerComponent.css';

/*
 * 	Props:
 *	- callback
 */
export default class ResizeListenerComponent extends Component {

	componentDidMount() {
		var self = this,
			node = ReactDOM.findDOMNode(self);
		new ResizeSensor(node, function() {
			self.onResize(node);
		});
		self.onResize(node);
	}

	onResize = (node) => {
		this.props.callback({
			w: node.clientWidth,
			h: node.clientHeight,
		});
	}

	render() {
		return (
			<div className='resize-listener'>
				{ this.props.children }
			</div>
		)
	}

}