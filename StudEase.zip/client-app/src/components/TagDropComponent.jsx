import React, { Component } from 'react';
import Select from 'react-select';



export default class TagDropComponent extends Component {
  constructor(props) {
    super(props);
   this.state = {
      val: null,
      options: [{
        value: 'final',
        label: 'Final'
      }, {
        value: 'midterm',
        label: 'Midterm'
      }]
    };
  }
render() {
    
    const onChange = (selections) => {
      
      const newOptions = [].concat(this.state.options);
      
      selections.forEach(selection => {
        const match = this.state.options.find(
          entry => (entry.value == selection.value));
        if (!match) {
        	newOptions.add(match);
        }
      });
      
      this.setState({
        val: [].concat(selections),
        options: newOptions
      });
    };
    
    return (<div>
      <Select.Creatable name = "form-field-name"
            multi={true}
            value = {this.state.val}
            options = {this.state.options}
            onChange = {onChange}
            />
    </div>);
  }
}
