import React, { Component } from 'react';
import searchScore from '../utilities/search.js';
import Firebase from '../utilities/firebase.js';

import '../../public/css/ActiveUserComponent.css';


export default class SessionListComponent extends Component {
        
        //Constructor
        constructor(props, context) {
		super(props, context);
                this.state = {
                    UsersList: [],
                    UserNames: [],
                    ActiveUsersList: [],
                };
	}
        
        //works
        //fillUserList
        fillUserList(){
            var self = this;
            
            //Get the List of users in the Class
            Firebase.getUsersInClass(self.props.courseId, function(err, items){
                if(!err){
                    self.state.UserSessList = items;
                }
            });
        }
        
        //does NOT work
        fillNames(userIDList){
            var self = this;
            //probably same issue as before. Doesnt like a forEach followed by a firebase function... for some reason
            userIDList.forEach(function(userID){
                //maybe something wrong with the firebase function?
                Firebase.getUserName(userID, function(err, item){
                    if(!err){
                        self.state.UserNames.push(item);
                    }else{
                        //todo: error message or event
                    }
                });
            });
            
        }
        
        //commented until i fix this part.
        refresh(){
            var self = this;
            self.fillUserList();
            self.fillNames(self.state.UserSessList);
            //self.state.UserNames.forEach(function(name){
            //    Firebase.getActiveUser(name, function(err, tf){
            //        self.state.ActiveUsersList.push(name);
            //    });
            //});
            return self.state.ActiveUsersList;
        }
        
        render(){
            var self = this;
            //this.state.ActiveSessList= [10, 11, 12];
            return(
                    <div className='Sess-List'>
                        <ul>1</ul>
                    </div>
            )
        }
}
