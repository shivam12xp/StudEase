import React, { Component } from 'react';
import { Link } from 'react-router';
import searchScore from '../utilities/search.js';
import Firebase from '../utilities/firebase.js';
import chat from '../utilities/firechat.js';
import { Glyphicon } from 'react-bootstrap';
import { Popover } from 'react-bootstrap';
import { OverlayTrigger } from 'react-bootstrap';

import '../../public/css/SessComponent.css';


/* PROPS
- sessId
- sessName
- courseId
- onClick
*/

export default class SessComponent extends Component {
        
        constructor(props, context) {
        super(props, context);
                this.state = {
                    activeNum: 0,
                    actives: [],
                    activeUserNames: [],
                    sessName: "",
                };
    }
        
        componentWillMount(){
                var self = this;
                var tempUserNames = [];
                Firebase.getSessActives(self.props.sessId, function(err, actives){
                    actives.forEach((activeUser, index) => {
                        Firebase.getUserName(activeUser, function(err, activeUserName){
                            tempUserNames = self.state.activeUserNames;
                            var tempUser=new Object;
                            tempUser.name = activeUserName;
                            tempUserNames[index]=tempUser;
                            self.setState({
                                activeUserNames: tempUserNames
                            });
                        });
                        Firebase.getPhoto(activeUser, function(err, activeUserPhotoUrl){
                            tempUserNames = self.state.activeUserNames;
                            tempUserNames[index].photoUrl=activeUserPhotoUrl;
                            self.setState({
                                activeUserNames: tempUserNames
                            });
                        });
                    });
                    if(!err){
                        self.setState({
                            activeNum: actives.length,
                            actives: actives,
                        });
                    }else{
                        self.setState({
                            activeNum: 0
                        });
                    }
                });
                Firebase.getSessName(self.props.sessId, function(err, name){
                   if(!err){
                       self.setState({
                            sessName: name,
                        });
                   } else{
                      self.setState({
                            sessName: "untitled"
                        }); 
                   }
                });

        }

        // getIcon = () => {
        //     var self = this;
        //     if(self.state.activeNum > 0){
        //         return "user";
        //     }else{
        //         return "minus";
        //     }
        // }


    
        render(){
            var self = this;

            var imageClass = 'session-user-image';

            if(this.state.activeNum!=0){
                var activeUsers = (
                    <div>            
                    {
                        this.state.activeUserNames.map((tempUserName) => { 
                                var userImage = (
                                    <img className={ imageClass } src={ tempUserName.photoUrl } role='presentation' />
                                );
                                return <div>{userImage}{tempUserName.name}</div>
                            
                        })
                    }
                    </div>
                );
            }
            else{
                var activeUsers= ( <div>None</div>);
            }

            var hoverInfo = (
                    <Popover id="popover-trigger-hover-focus" title={ "Users Online" }>
                        {activeUsers}
                    </Popover>
            );

            var sessionInfo = (
                <div className='session-info-primary'>
                    <div id="popover" className='session-content-container'>
                        <div className='session-video-icon-background'>
                            <span className="session-video-icon">
                                <Glyphicon glyph="facetime-video" />
                            </span>
                        </div>
                        <div className='session-name'>
                            { self.state.sessName }
                        </div>
                        <div className='session-meta'>
                          
                        </div>

                        <span className="badge" class="badge badge-default pull-right">
                            <Glyphicon glyph="user" />
                            <span className="space"></span>
                            {self.state.activeNum}
                        </span>
                    </div>
                </div>

            );

            return(
                <OverlayTrigger trigger="hover" placement="right" overlay={ hoverInfo }>
                    <div id='session-info-popover' className='session-info' onClick={ self.props.onSelect }>
                            { sessionInfo }
                    </div>
                </OverlayTrigger>

            );
        }
}