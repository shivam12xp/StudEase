import React, { Component } from 'react';

import '../../public/css/BigCardComponent.css';
import '../../public/css/BigCardTabComponent.css';

export default class BigCardTabComponent extends Component {

	constructor (props, context) {
		super(props, context);
		this.state = {
			index: this.props.defaultIndex || 0
		}
		this.randomKey = 0;
	}

	setIndex (index) {
		this.setState({ index: index });
	}

	getOnClickTab (index) {
		var self = this;
		return function () {
			self.randomKey = Math.random();
			self.setState({ index: index });
		};
	}

	render() {
		var headerClasses = 'big-card-header big-card-header-2 ' + this.props.theme;
		var self = this;
		return (
			<div className='big-card'>
				<div className='big-card-inner'>
					<div className={ headerClasses }>
						{
							self.props.children.map((child, index) => {
								var titleClasses = 'big-card-header-tab ' + this.props.theme
									+ (index === self.state.index ? ' selected' : ' unselected' );
							    return (
							        <div className={ titleClasses } key={ index } onClick={ self.getOnClickTab(index) }>
							            <span className='big-card-header-title'>{ child.props.title }</span>
							        </div>
							    );
							})
						}
					</div>
					<div className='big-card-content'>
						{ 
							self.props.children.map((child, index) => {
								var childClasses = 'big-card-content-wrapper';
								if (index !== self.state.index) {
									childClasses += ' hidden';
								}
							    return (
							        <div className={ childClasses } key={ 'content' + index + (child.props.forceRefresh ? this.randomKey : 0) }>
							            { child }
							        </div>
							    );
							})
						}
					</div>
				</div>
			</div>
		);
	}


}