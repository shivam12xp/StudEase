import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import chat from '../utilities/firechat.js';
import ChatMessageComponent from './ChatMessageComponent.jsx';

import '../../public/css/ChatComponent.css';

/**
 *	Props:
 *	-	roomId
 */
export default class ChatComponent extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {
			messages: [],
			string: ''
		};
		this.doScrollDown = true;
	}

	componentWillMount() {
		chat.mountComponent(this.props.roomId, this);
		console.log('mount');
	}

	componentWillUnmount() {
		chat.unmountComponent(this.props.roomId, this);
		console.log('unmount');
	}

	componentDidUpdate() {
		if (this.doScrollDown) {
			this.scrollToBottom();
		}
	}
	componentDidMount() {
		if (this.doScrollDown) {
			this.scrollToBottom();
		}
	}

	onMessagesUpdated = (messages) => {
		this.setState({
			messages: messages
		});
		console.log('updated');
		console.log(messages);
		this.doScrollDown = true;
	}

	handleChange = (event) => {
		this.setState({
			string: event.target.value.replace(/\:\)/g, "😄").replace(/\:\(/g, "😞")
		});
	}

	handleSubmit = (event) => {
		event.preventDefault();
		if (this.state.string && this.state.string.length > 0) {
			chat.sendMessage(this.props.roomId, this.state.string);
			this.setState({ string: '' });
			console.log(this.state.string);
		}
		return false;
	}

	scrollToBottom = () => {
    	const node = ReactDOM.findDOMNode(this.bottomOfChat);
    	if (node) {
	    	node.scrollIntoView();
	    }
	    this.doScrollDown = false;
	}


	render() {
		var sendButtonClasses = "simpleform-button fa fa-paper-plane";
		if (!this.state.string || this.state.string.length <= 0) {
			sendButtonClasses += " hidden";
		}
		return (
			<div className='chat-box'>
				<div className='messages'>
					{ this.state.messages.map((message, index) => {
					    return (
					        <div key={index}>
					            <ChatMessageComponent message={ message }/>
					        </div>
					    );
					}) }
					<div ref={(div) => { this.bottomOfChat = div; }}/>
				</div>
				<form className="simpleform" onSubmit={this.handleSubmit}> 
					<input className='input-box'
	  					type="text"
	  					value={this.state.string}
	  					placeholder="Type a message..."
	  					onChange={this.handleChange} />
	  				<i className={ sendButtonClasses } onClick={this.handleSubmit} aria-hidden="true"></i>
	  			</form>
			</div>
		);
	}

}