import React, { Component } from 'react';

/**
 *	Props:
 * 	-	contents: list of contents
 */
export default class SiebarSlideComponent extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {
			content: null,
			contentKey: null
		};
	}

	toggle = (content, key) => {
		if (!content || this.state.contentKey === key) {
			this.hide();
			return null;
		} else {
			this.show(content, key);
			return key;
		}
	}

	show = (content, key) => {
		this.setState({
			content: content,
			contentKey: key
		});
	}

	hide = () => {
		this.setState({
			content: null,
			contentKey: null
		});
	}

	render() {
		if (this.state.content !== null) {
			return (
				<div className='sidebar-sliding active'>
					{ this.state.content }
				</div>
			);
		} else {
			return (
				<div className='sidebar-sliding'>
					
				</div>
			);
		}
	}

}