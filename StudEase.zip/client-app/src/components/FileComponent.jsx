import React, { Component } from 'react';
import drive from '../../public/drive.png';
import docs from '../../public/docs.png';
import slides from '../../public/slides.png';
import sheets from '../../public/sheets.png';
import starClicked from '../../public/star.png'
import starUnclicked from '../../public/starUnclicked.png'
import chat from '../utilities/firechat.js'
import { Modal, Button } from 'react-bootstrap';
import TagEditComponent from './TagEditComponent.jsx';
import Metadata from '../utilities/metadata.js';

import '../../public/css/FileComponent.css';
import 'react-select/dist/react-select.css';

var validThemes = { 'application/vnd.google-apps.document':docs, 'application/vnd.google-apps.presentation':slides, 'application/vnd.google-apps.spreadsheet':sheets };
var maxTagChars = 15;

var getTimeString =function(numMillis) {
        if (numMillis === 1) {
		return '1 miillisecond';
	} else if (numMillis < 1000) {
		return numMillis + ' milliseconds';
	}
	var numSeconds = Math.floor(numMillis / 1000);
	if (numSeconds === 1) {
		return '1 second';
	} else if (numSeconds < 60) {
		return numSeconds + ' seconds';
	}
        var numMinutes = Math.floor(numSeconds / 60);
	if (numMinutes === 1) {
		return '1 minute';
	} else if (numMinutes < 60) {
		return numMinutes + ' minutes';
	}
	var numHours = Math.floor(numMinutes / 60);
	if (numHours === 1) {
		return '1 hour';
	} else if (numHours < 48) {
		return numHours + ' hours';
	}
	var numDays = Math.floor(numHours / 24);
	if (numDays === 1) {
		return '1 day';
	}
	return numDays + ' days';
}

/**
 *	Props:
 *	-	onSelect (callback)
 *	- 	file
 *	-	fileOnUpvote method
 *  -   currentFile
 *	-	allTags
 */
export default class FileComponent extends Component {

	constructor (props, context) {
		super(props, context);
		this.state = {
			clicked: false,
			showModal: false,
			minutes: ""
		}
	}
	
	componentWillMount(){
            var self = this;
            
            Metadata.getFileMetadata(self.props.file.id, function(err, data){
                if(!err && data){
                    var date = new Date(data.modified);
                    var today = new Date();
                    var time = today.getTime();
                    var numMillis = time - date.getTime();
                    var timeString = getTimeString(numMillis);
                    console.log(timeString);
                   self.setState({
                      minutes:  timeString
                   });
                }
            });
        }

	getImgUrl() {
		return validThemes[this.props.file.theme]|| drive;
	}

	getExtraTagComponent(extraTags) {
		if (extraTags > 0) {
			return (
				<span className='file-tag-more'>{ ' + ' + extraTags + ' more' }</span>
			);
		}
		return null;
	}

	getTagsComponent(event) {
		var self = this;
		
		if (self.props.hideTags === true) {
			return('');
		}

		var tags = Object.keys(self.props.file.tags) || [];
		var tagEditStr = tags && tags.length > 0 ? 'edit tags' : 'add tags'
		if (tags) {
			var tagStr = tags.map(function(tag, index){
				return tag.length > maxTagChars - 2
	        		? tag.slice(0,maxTagChars) + '...'
	        		: tag;
			}).join(' ');
			return (
				<div className={ 'file-tag-container' }>
					<div className={ 'file-tag-group' + (tags && tags.length > 0 ? '' : ' hidden') }>
						{tagStr}
					</div>
					<div className='file-tag-edit' onClick={(event) => this.open(event)}>
						{ '(' + tagEditStr + ')' }
					</div>
					<Modal show={this.state.showModal} onHide={this.close}>
			          <Modal.Header closeButton>
			            <Modal.Title>{ 'Edit Tags - ' + this.props.file.name }</Modal.Title>
			          </Modal.Header>
			          <Modal.Body>
			          	<TagEditComponent fileId={this.props.file.id} allTags={this.props.allTags}/>
			          </Modal.Body>
			          <Modal.Footer>
			            <Button onClick={this.close}>Close</Button>
			          </Modal.Footer>
			        </Modal>
				</div>
			);
		}
		return null;
	}

	close = () => {
    	this.setState({ showModal: false });
 	}

  	open(e) {
  		e.stopPropagation();
  		console.log('openModal')
    	this.setState({ showModal: true });
 	}

	updateStarOnClick(file, e) {
		var self = this;
		e.stopPropagation();
		self.props.onUpvote(self.props.file);
	}

	getUpvotes() {
		var self = this;
		var upvoted;
		var imgSrc;
		if (self.props.file.upvotes === 0) {
			upvoted = false;
			imgSrc = starUnclicked;
		}
		else {
			upvoted = (self.props.file.upvoters || {})[chat.user.id];
			imgSrc = upvoted ? starClicked : starUnclicked;
		}

		return (
			<div className='file-star-container'>
				<input className='file-star' type='image' src={ imgSrc } onClick={ (event) => self.updateStarOnClick(self.props.file, event) } />
				<div className='file-star-upvote-count'>{ self.props.file.upvotes }</div>
			</div>
		);
	}

	render() {

		// Display placeholder user image while waiting for real image to be retrieved
		var imageClass = 'file-icon';
		var fileIcon = (
			<img className={ imageClass } src={ this.getImgUrl() } role='presentation' />
		);
		var imageClassDash = 'file-icon-dash';
		var fileIconDash = (
			<img className={ imageClassDash } src={ this.getImgUrl() } role='presentation' />
		);

		var self = this;

		var fileInfoComponent = (
			<div className='file-info-primary'>
				<div className='file-icon-container'>
					{ fileIcon }
				</div>
				<div className='file-content-container'>
					<div className='file-name'>
						{ self.props.file.name }
					</div>
					<div className='file-meta'>
						<span className='file-meta-content'>{ 'Modified ' + self.state.minutes + ' ago' }</span>
					</div>
				</div>
				{ self.getUpvotes() }
			</div>
		);

		return (
			<div className={ self.props.currentFile === true ? 'file-info-selected' : 'file-info' } onClick={ self.props.onSelect }>
				{ fileInfoComponent }
				{ self.getTagsComponent() }
			</div>
		);
		
	}

}
