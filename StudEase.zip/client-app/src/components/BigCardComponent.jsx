import React, { Component } from 'react';

import '../../public/css/BigCardComponent.css';

export default class BigCardComponent extends Component {

	render() {
		var headerClasses = 'big-card-header ' + this.props.theme;
		return (
			<div className='big-card'>
				<div className='big-card-inner'>
					<div className={ headerClasses }>
						<span className='big-card-header-title'>{ this.props.title }</span>
					</div>
					<div className='big-card-content'>
						{ this.props.children }
					</div>
				</div>
			</div>
		)
	}

}