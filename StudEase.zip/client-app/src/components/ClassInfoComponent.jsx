import React, { Component } from 'react';

import '../../public/css/ClassInfoComponent.css';

/**
 *	Props:
 *	-	class name
 *	-	class description
 */
export default class ClassInfoComponent extends Component {

	render() {
		var self = this;

		return (
			<div className='class-info'>
				<div className='class-info-primary'>					
					<div className='class-info-content-container'>
						<h4 className='class-name'>
							{ self.props.name }
						</h4>
						<div className='class-desc'>
							{ self.props.desc }
						</div>
					</div>
				</div>
			</div>
		);
	}

}