import React, { Component } from 'react';
import { Link } from 'react-router';
import searchScore from '../utilities/search.js';
import Firebase from '../utilities/firebase.js';
import Firebase2 from '../utilities/firebase2.js';
import chat from '../utilities/firechat.js';
import SessComponent from '../components/SessComponent.jsx';
import '../../public/css/SessionListComponent.css';
import { Button, Modal, FormGroup, ControlLabel, FormControl } from 'react-bootstrap';

class SessionListComponent extends Component {

    //Constructor
    constructor(props, context) {
		super(props, context);
        this.state = {
            ActiveSessList: [],
            showModal: false,
            sessionName: ''
        };
    }
    
    componentWillMount(){
        var self = this;
        Firebase.getSessionsFromClass(self.props.courseId, function(err, items){
            if (!err) {
                
                self.setState({
                        ActiveSessList: items
                });
                console.log("active sess list: " + self.state.ActiveSessList);
            //If no sessions in class yet
            } else {
                self.setState({
                    ActiveSessList: <button disabled>
                            <Link to='session'>No Sessions...</Link>
                    </button>
                });
            }
        });
                
    }
    
    goToSess = (SessID) => {
        this.props.sessId = SessID;
        this.context.router.push('/dashboard');
    }

    toggleModal = () => {
        this.setState(prevState => ({ showModal: !prevState.showModal }));
    }

    handleModalInputChange(event) {
        var newSessionName = event.target.value;
        this.setState({ sessionName: newSessionName });
    }

    createSession = () => {
        var self = this;
        self.toggleModal();
    }

    handleCreateSession = () => {    
        var roomId = '';    
        var self = this;
        Firebase2.addSession({
            name: this.state.sessionName,
            courseId: this.props.courseId,
        }, function(err, data) {
            if (err || !data) {
                console.log('handle create session error');
            }
            else {
                console.log('handle create session success');
                roomId = data;
                console.log('roomId is ' + roomId);

                self.context.router.push('/course/' + self.props.courseId + '/session/' + roomId);
            }
        });
        //TODO
        // setTimeout(this.context.router.push('/course/' + this.props.courseId + '/session/' + roomId), 200);
        // this.context.router.push('/course/' + this.props.courseId + '/session/' + roomId);
    }

        
    //render function
    render(){
        var self = this;
        var sessions = self.state.ActiveSessList;

        return(
            <div className='sess-list-wrapper'>
                <div className='sess-List'>
                    {sessions.map((session, index) => {
                        return(
                            <SessComponent key={index}
                                sessId={ session }
                                courseId={self.props.courseId}
                                sessName="tempName" // TODO FILL IN WHEN WE ACTUALLY DO CREATE SESSION
                                onSelect={ () => { self.props.onSessionSelected(session) } }
                            />
                        );
                    })}

                </div>

                <div className="modal-container" style={{height: 0}}>
                    <Modal show={this.state.showModal} onHide={self.toggleModal} container={this} aria-labelledby="contained-modal-title">
                        <Modal.Header className='modal-header'>
                            <Modal.Title id="contained-modal-title">Create New Study Session</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <form>
                                <FormGroup controlId="formBasicText">
                                  <ControlLabel>Session Name</ControlLabel>
                                  <FormControl
                                    id="sessName"
                                    type="text"
                                    value={ this.state.sessionName }
                                    placeholder="Enter name..."
                                    onChange={ (event) => self.handleModalInputChange(event) }
                                  />
                                </FormGroup>
                            </form>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button onClick={ self.toggleModal }>Close</Button>
                            <Button onClick={ self.handleCreateSession } bsStyle="primary">Create</Button>
                        </Modal.Footer>
                    </Modal>
                </div>

                <div className={ 'big-card-footer' + (this.props.hideAddButton ? ' hidden' : '') }>
                    <button className='btn simplebutton' onClick={ this.createSession }>
                        Create Session
                    </button>
                </div>
            </div>
        )
    }
}


SessionListComponent.contextTypes = {
    router: React.PropTypes.object
};

export default SessionListComponent;
