import React, { Component } from 'react';

import PeerVideo from '../utilities/peerVideo.js';
import chat from '../utilities/firechat.js';

/*
 * 	Props:
 *	- user: user metadata
 *	- stream: stream
 */
export default class VideoComponent extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {
			muted: false,
			//hovering: false
		}
	}

	// Mute self
	handleMuteSelf = () => {
		PeerVideo.updateUserMedia({ audio: this.state.muted });
		this.setState({
			muted: !this.state.muted
		});
	}

	// Mute another user
	handleMuteOther = () => {
		this.setState({
			muted: !this.state.muted
		});
	}

	/*
	handleMouseEnter = () => {
		this.setState({
			hovering: true
		});
	}

	handleMouseLeave = () => {
		this.setState({
			hovering: false
		});
	}
	*/

	// Renders the component upon each change of state
	render() {
		console.log(this.props.user);
		console.log(chat.user.id);
		var isLocalUser = this.props.user && chat.user.id === this.props.user.id;

		var handleMute = isLocalUser ? this.handleMuteSelf : this.handleMuteOther;

		var videoClass = 'vidchat-video';
		var muteBtnClass = 'fa fa-circle vidchat-btn-outer'
			+ (this.state.muted ? ' muted' : '');
		var muteBtnInnerClass = 'fa vidchat-btn vidchat-btn-inner';
		if (isLocalUser) {
			muteBtnInnerClass += (this.state.muted ? ' fa-microphone-slash' : ' fa-microphone');
		} else {
			muteBtnInnerClass += (this.state.muted ? ' fa-volume-off' : ' fa-volume-up');
		}
		var nameClass = 'vidchat-name'
			+ (this.state.hovering ? '' : ' hide');

		return (
			<div className='vidchat-video-container'
				onMouseEnter={ this.handleMouseEnter }
				onMouseLeave={ this.handleMouseLeave }
			>
				<video className={ videoClass }
					src={ this.props.stream }
					muted={ this.state.muted || isLocalUser }
					autoPlay
				/>
				<h4 className={ nameClass }>
					{ this.props.user ? this.props.user.name : '' }
				</h4>
				<i className={ muteBtnClass } aria-hidden='true' onClick={ handleMute }>
					<i className={ muteBtnInnerClass } aria-hidden='true'/>
				</i>
			</div>
		);
	}

}

