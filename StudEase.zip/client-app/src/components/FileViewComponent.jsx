import React, { Component } from 'react';

import FileListComponent from '../components/FileListComponent.jsx'
import FileFrameComponent from '../components/FileFrameComponent.jsx';
import BigCardComponent from '../components/BigCardComponent.jsx';
import BigCardTabComponent from '../components/BigCardTabComponent.jsx';

// var courseId = "cs-189a";
// var roomId = "-KVhUUhx-NWqQ-3CFM91";

/**
 *	Props:
 *	-	roomId (if not specified, all rooms in class)
 *  -   courseId
 */

export default class FileViewComponent extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {
			title: '',
			description: '',
			sessionOnly: true,
			starredFilesChecked: false
		};
	}

	componentWillMount() {
		this.fileOverrideId = this.props.initialFileId;
	}

	updateSelectedFile = (file) => {
		this.fileOverrideId = null;
		this.setState({
			file: file
		});
		this.refs.fileViewTabComponent.setIndex(1); // switch to file tab
	}

	handleSessionOnly = (checked) => {
		this.setState({ sessionOnly: checked })
	}

	handleStarredFilesCheckboxChange = (checked) => {
		this.setState({ starredFilesChecked: checked })
	}

	getFileViewComponent () {
		var self = this;
		if (self.state.file) {
			var file = self.state.file;
			return (
				<BigCardTabComponent theme={ file.theme } ref="fileViewTabComponent" defaultIndex={1}>
					<FileListComponent courseId={ this.props.courseId } roomId={ this.props.roomId } title="Files"
						forceRefresh={ true }
						onFileSelected={self.updateSelectedFile}
						currentFile={ this.state.file.id}
						inCourse={this.props.inCourse}
						onSessionCheckboxChange={self.handleSessionOnly}
						sessionChecked={self.state.sessionOnly}
						onStarredFilesCheckboxChange={self.handleStarredFilesCheckboxChange}
						starredFilesChecked = {self.state.starredFilesChecked}

					/>
					<FileFrameComponent title={ file.name } fileId={ file.url } />
				</BigCardTabComponent>
			);
		} else {
			return (
				<BigCardComponent title="Files">
					<FileListComponent courseId={ this.props.courseId } roomId={ this.props.roomId } 
						onFileSelected={self.updateSelectedFile}
						fileOverrideId={self.fileOverrideId}
						inCourse={this.props.inCourse}
						onSessionCheckboxChange={self.handleSessionOnly}
						sessionChecked={self.state.sessionOnly}
						onStarredFilesCheckboxChange={self.handleStarredFilesCheckboxChange}
						starredFilesChecked = {self.state.starredFilesChecked}
					/>
				</BigCardComponent>
			);
		}
	}

	render() {
		return (
			<div className='layout'>
			{	this.getFileViewComponent()}
			</div>
		);
	}

}
