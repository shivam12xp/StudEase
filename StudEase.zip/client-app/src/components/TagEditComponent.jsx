import React, { Component } from 'react';
import { FormGroup, ControlLabel, FormControl } from 'react-bootstrap';

import Firebase from '../utilities/firebase.js';
import googleAPI from '../utilities/googleapi.js';

import '../../public/css/TagEditComponent.css';

// prop: allTags
/* Usage:
 *	<TagEditComponent fileId='FILE_ID_HERE' allTags={ fileid1: true, fileid2: true, ... }/>
 */

export default class TagEditComponent extends Component {

	constructor (props, context) {
		super(props, context);
		this.state = {
			file: null,
			inputString: '',
			suggestedTags: [] // array of tag ids
		}
	}

	componentWillMount () {
		var self = this;
		Firebase.ref('files/' + self.props.fileId).on('value', function(snapshot) {
			var f = snapshot.val();
			console.log(self.props.fileId);
			if (f) {
				self.setState({ file: f });
			}
		});
		googleAPI.getContentPlainText(this.props.fileId, function(plainTextContent){
			self.setSuggestedTags(plainTextContent);
		});
	}

	setSuggestedTags = (plainTextContent) => {
		var self = this;
		var suggestedTagsKey = {};

		Object.keys(self.props.allTags).map(function(tag, index) {
			var regExp = new RegExp(tag, 'igm'); //i flag ignores case, g does global search
			var tagCount = (plainTextContent.match(regExp) || []).length; //search returns count, match returns array
			
			if(tagCount != 0){
				suggestedTagsKey[tag] = tagCount;
			}
		})
		self.setState({ 
			suggestedTags: Object.keys(suggestedTagsKey).sort((a, b) => suggestedTagsKey[b] - suggestedTagsKey[a])
		});

	}

	// Input events

	handleChange = (event) => {
		this.setState({
			inputString: event.target.value
		});
	}

	handleClear = (event) => {
		this.setState({
			inputString: ''
		});
	}

	handleSubmit = (event) => {
		event.preventDefault();
		var fileId = this.props.fileId;
		this.state.inputString.match(/\S+/g).forEach(function(word) {
			Firebase.addTagToFile(fileId, word.toLowerCase(), () => {});
		});
		console.log('tagAdded');
		this.setState({
			inputString: ''
		});
		return false;
	}

	handleRemove = (event, tag) => {
	console.log("handleRemove");
	console.log(tag);
	var self = this
	Firebase.removeTag(self.props.fileId,tag);

	}

	handleSuggested = (event, tag) => {
		var self = this;
		var fileId = self.props.fileId;
		Firebase.addTagToFile(fileId, tag.toLowerCase(), () => {});
	}

	// Render

	// TODO
	// render suggested tags below the input form
	// onclick -> add tag to the file
	getSuggestedTagsComponent = (suggestedTags) => {
		//suggestedTags = { 'fake': true}
		if (!suggestedTags || suggestedTags.length <= 0) {
			return '';
		}
		var buttonClassesPlus = "simpleform-button fa fa-plus";
		var self = this;
		return (
			<div>
				<h5>Suggested Tags</h5>
				{
					suggestedTags.map(function(tag, index) {
						return (
							<div className='tag-edit-tag' onClick={(event)=> self.handleSuggested(event, tag)}>
							<i className={ buttonClassesPlus } aria-hidden="true"></i>
								{ tag }
							</div>
						);
					})
				}
			</div>
		);
	}

	render () {
		var buttonClassesX = "simpleform-button fa fa-times";

		var tags = (this.state.file && this.state.file.tags)
			? this.state.file.tags
			: {};

		var suggestedTags = this.state.suggestedTags.filter((tag) => !tags[tag]).slice(0, 8);

		var self = this;
		return (
			<div className='tag-edit'>

				<div className='tag-edit-tags-container'>

					{
						(Object.keys(tags)).map(function(tag, index) {
							return (
								<div className='tag-edit-tag tag-edit-tag-bright' onClick={(event)=> self.handleRemove(event, tag)}>
								<i className={ buttonClassesX } aria-hidden="true"></i>
									{ tag }
								</div>
							);
						})
					}
				</div>

				<form onSubmit={this.handleSubmit}>
					<FormGroup controlId="formBasicText">
					  <ControlLabel>{ this.state.file.name }</ControlLabel>
					  <FormControl
						type="text"
						value={ this.state.inputString }
						placeholder="Type a new tag..."
						onChange={this.handleChange}
						/>
					</FormGroup>
				</form>

				{
					self.getSuggestedTagsComponent(suggestedTags)
				}

			</div>
		);
	}

}