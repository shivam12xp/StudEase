import React from 'react';
import ReactDOM from 'react-dom';
import Firebase from '../utilities/firebase.js';
import Firebase2 from '../utilities/firebase2.js';
//var Firebase = require("firebase");
/*
 * Set this to false when you want to see full test results
 */
var show_test_results = false;


// Helper functions to generate (probably) unique IDs
var getUniqueFileId = function() {
	return 'file_' + Math.round(Math.random()*Number.MAX_SAFE_INTEGER) + 1;
}
var getUniqueClassId = function() {
	return 'class_' + Math.round(Math.random()*Number.MAX_SAFE_INTEGER) + 1;
}


// Hacky stuff to force the test runner to exit (bc it hangs when testing asynch code)
var num_active_tests = 0;
var num_failures = 0;

beforeEach(function() {
	num_active_tests += 1;
});

var finish = function () {
	if (num_failures <= 0) {
		console.log('\n\nAll tests passed! Your commit is valid.\n');
		process.exit(num_failures);
	} else {
		console.log('\n-------------------------------------------------------'
			+ '\n' + num_failures + ' tests failed. Your commit was rejected.\n'
			+ '\nPress CTRL+C to abort.\n'
		);
	}
}
var succeed = function(done) { 
	if (!show_test_results) {
		num_active_tests -= 1;
		if (num_active_tests <= 0) {
			finish ();
		}
	}
	done();
}
var fail = function(done) {
	if (!show_test_results) {
		num_active_tests -= 1;
		num_failures += 1;
		if (num_active_tests <= 0) {
			finish ();
		}
	}
	done.fail();
}


/*
 * TESTS
 */

describe('DB tests', () => {

//--------------------------Test1-----------------------------------------------
	// Example of how to test async code
    /*
	test ("Example async test: check that some random fileId doesn't exist", done => {
		var fileId = getUniqueFileId();
		Firebase.getFile(fileId, function(err, data){
			if (err || !data) {
				succeed(done);
			} else {
				fail(done);
			}
		});
	});
    */





//--------------------------Test2-----------------------------------------------
	/*
	 *	Add a class record
	 *	Verify that the class record exists
	 *	Delete the class
	 *	Verify that the classs record no longer exists
	 */
     /*
	test ('Test class creation / deletion', done => {
            
            var classId = getUniqueClassId();
            
            //add class record
            Firebase.addClass(classId, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //verify class record exists
            Firebase.getClass(classId, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //remove class
            Firebase.removeClass(classId);
            
            //verify class is removed
            Firebase.getClass(classId, function(err, data){
               if(err || !data){
                   succeed(done);
               }else{
                   fail(done);
               }
            });
            
	});
    */


//--------------------------Test3-----------------------------------------------
	/*
	 *	Use a real userId (Capstone Citrix test user = bFJzRe6kygdA2zhq3kTLCuZE9Yz2)
	 *	Add two class records
	 *	Add the user to two classes
	 *	Verify that the user is in both class records
	 *	Verify that the user record contains both classes
	 *	Delete one class
	 *	Remove the user from the other class, but do not delete the class
	 *	Verify that the user record no longer contains the classes
	 *	Delete the other class
	 */
     /*
	test ('Test user interaction with classes', done => {
            var classId1 = getUniqueClassId();
            var classId2 = getUniqueClassId();
            var userId = 'bFJzRe6kygdA2zhq3kTLCuZE9Yz2';
            
            //create two class records
            Firebase.addClass(classId1, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            Firebase.addClass(classId2, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //add user to classes
            Firebase.addUserToClass(userId, classId1, function(err, data){
               if(err || !data){
                   fail(done);
               } 
            });
            Firebase.addUserToClass(userId, classId2, function(err, data){
               if(err || !data){
                   fail(done);
               } 
            });
            
            //verify user is in both class records
            Firebase.getUserInClass(classId1, userId, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            Firebase.getUserInClass(classId2, userId, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //verify user record has both classes
            Firebase.getClassInUser(userId, classId1, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            Firebase.getClassInUser(userId, classId2, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //delete class1
            Firebase.removeClass(classId1);
            
            //remove user from class2
            Firebase.removeUserFromClass(userId, classId2);
            
            //verify user record no longer contains class1 or class2
            Firebase.getClassInUser(userId, classId1, function(err, data){
                if(err || !data){
                }else{
                    fail(done);
                }
            });
            Firebase.getClassInUser(userId, classId2, function(err, data){
                if(err || !data){
                }else{
                    fail(done);
                }
            });
            
            //delete class2
            Firebase.removeClass(classId2);
      
            succeed(done);
	});
    */


//--------------------------Test4-----------------------------------------------
	/*
	 *	Add a file record & two class records
	 *	Verify that the file record exists
	 *	Add the file to an additional class
	 *	Verify that the file is in both class records
	 *	Verify that the file record contains both classes
	 *	Delete the file
	 *	Verify that the file record no longer exists
	 *	Verify that the class records no longer contains the file
	 * 	Delete the class records
	 */
     /*
	test ('Test file creation / deletion + interaction with classes', done => {
            var classId1 = getUniqueClassId();
            var classId2 = getUniqueClassId();
            var fileId = getUniqueFileId();
            
            //create two class records
            Firebase.addClass(classId1, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            Firebase.addClass(classId2, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //create a file record
            Firebase.addFile(fileId, classId1, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //verify file exists
            Firebase.getFile(fileId, function(err, data){
			if (err || !data) {
				fail(done);
			}
            });
            
            //add file to class2
            Firebase.addFile(fileId, classId2, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //verify file is in both class records
            Firebase.getFileInClass(classId1, fileId, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            Firebase.getFileInClass(classId2, fileId, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //verify classes are in file record
            Firebase.getClassInFile(fileId, classId1, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            Firebase.getClassInFile(fileId, classId2, function(err, data){
                if(err || !data){
                    fail(done);
                }
            });
            
            //delete File
            Firebase.removeFile(fileId);
            
            //verify file record is removed
            Firebase.getFile(fileId, function(err, data){
			if (err || !data) {
			} else {
				fail(done);
			}
		});
                
            //verify file is removed from classes
            Firebase.getFileInClass(classId1, fileId, function(err, data){
			if (err || !data) {
			} else {
				fail(done);
			}
		});
            Firebase.getFileInClass(classId2, fileId, function(err, data){
			if (err || !data) {
			} else {
				fail(done);
			}
            });
            
            //remove classes
            Firebase.removeClass(classId1);
            Firebase.removeClass(classId2);
            
            succeed(done);
	});
    */
});

