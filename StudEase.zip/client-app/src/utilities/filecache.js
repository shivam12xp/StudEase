import Firebase from './firebase.js';
import Metadata from './metadata.js';


var filesBeingListenedTo = {}; // Set of fileIds
var driveDataCache = {}; // Map of fileId -> drive meta data
var dbDataCache = {}; // Map of fileId -> db data (upvotes / tags)

var sessionFilesCache = {}; // Map of sessionId -> Set of fileIds
var courseFilesCache = {}; // Map of courseId -> Set of fileIds

var fileListeners = {}; // Map of fileId -> Set of listening components which will also be in courseListeners or SessionListeners
var courseListeners = {}; // Map of courseId -> Set of listening components
var sessionListeners = {}; // Map of sessionId -> Set of listening components


var listenForFileChanges = function(fileId) {
	//console.log("LISTEN TO " + fileId);
	if (filesBeingListenedTo[fileId]) {
		onFileChanged(fileId);
		return;
	}

	filesBeingListenedTo[fileId] = true;
	Metadata.getFileMetadata(fileId, function(err, data) {
		if (!err && data) {
			driveDataCache[fileId] = data;
			onFileChanged(fileId);
		}
	});
	Firebase.ref('files/' + fileId).on('value', function(snapshot) {
		var file = snapshot.val();
		//console.log("HEARD CHANGE TO FILE", file);
		if (file) {
			dbDataCache[fileId] = file;
			onFileChanged(fileId);
		}
	});
}

var onFileChanged = function(fileId) {
	// Wait for both the db meta data and the drive meta data
	if (!driveDataCache[fileId] || !dbDataCache[fileId]) {
		return;
	}
	var file = Object.assign(driveDataCache[fileId], dbDataCache[fileId], {id: fileId});
	// Notify all the listeners
	for (var courseId in file.classes || {}) {
		if (courseListeners[courseId] && courseFilesCache[courseId]) {
			var files = {};
			for (var fileId in courseFilesCache[courseId]) {
				if (!driveDataCache[fileId] || !dbDataCache[fileId]) {
					continue;
				}
				var file = Object.assign(driveDataCache[fileId], dbDataCache[fileId], {id: fileId});
				files[fileId] = file;
			}
			for (var listener in courseListeners[courseId]) {
				var callback = courseListeners[courseId][listener];
				callback(files);
			}
		}
	}
	for (var sessionId in file.sessions || {}) {
		if (sessionListeners[sessionId] && sessionFilesCache[sessionId]) {
			var files = {};
			for (var fileId in sessionFilesCache[sessionId]) {
				if (!driveDataCache[fileId] || !dbDataCache[fileId]) {
					continue;
				} 
				var file = Object.assign(driveDataCache[fileId], dbDataCache[fileId], {id: fileId});
				files[fileId] = file;
			}
			for (var listener in sessionListeners[sessionId]) {
				var callback = sessionListeners[sessionId][listener];
				callback(files);
			}
		}
	}
}


export default class FileCache {

	// Course file list listeners

	static startListeningCourse (courseId, component, callback) {
		if (!courseListeners[courseId]) {
			courseListeners[courseId] = {};
			courseListeners[courseId][component] = callback;
			Firebase.ref('classes/' + courseId + '/files').on('value', function(snapshot) {
				courseFilesCache[courseId] = snapshot.val() || {};
				for (var fileId in courseFilesCache[courseId]) {
					listenForFileChanges(fileId);
				}
			});
		} else {
			courseListeners[courseId][component] = callback;
			var files = {};
			for (var fileId in courseFilesCache[courseId]) {
				if (!driveDataCache[fileId] || !dbDataCache[fileId]) {
					continue;
				}
				var file = Object.assign(driveDataCache[fileId], dbDataCache[fileId], { id: fileId });
				files[fileId] = file;
			}
			callback(files);
		}
	}

	static stopListeningCourse (courseId, component) {
		if (component === courseListeners[courseId][component]) {
			delete courseListeners[courseId][component];
		}
	}

	// Session file list listeners

	static startListeningSession (sessionId, component, callback) {
		if (!sessionListeners[sessionId]) {
			sessionListeners[sessionId] = {};
			sessionListeners[sessionId][component] = callback;
			Firebase.ref('chat/room-metadata/' + sessionId + '/files').on('value', function(snapshot) {
				sessionFilesCache[sessionId] = snapshot.val() || {};
				for (var fileId in sessionFilesCache[sessionId]) {
					listenForFileChanges(fileId);
				}
			});
		} else {
			sessionListeners[sessionId][component] = callback;
			var files = {};
			for (var fileId in sessionFilesCache[sessionId]) {
				if (!driveDataCache[fileId] || !dbDataCache[fileId]) {
					continue;
				}
				var file = Object.assign(driveDataCache[fileId], dbDataCache[fileId], { id: fileId });
				files[fileId] = file;
			}
			callback(files);
		}
	}

	static stopListeningSession (sessionId, component) {
		if (component === sessionListeners[sessionId][component]) {
			delete sessionListeners[sessionId][component];
		}
	}

}