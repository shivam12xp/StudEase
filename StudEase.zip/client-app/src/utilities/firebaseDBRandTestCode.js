var TestIt = require("./firebaseDB.js"); 

var Params = {
    userID: 200
};

//TestIt.post("classIDs/", "NewTest", Params);


//cant get the code quite right... array isnt populated... becuase of asynchronous updates? or something?
//idk out of my element on this one, will continue to fiddle with it
//currently this code is a mess though
//var Users = TestIt.UinR("CoolRoom");
//var ref = TestIt.ref("users/Brendan");
//ref.set({});

//updates userID w/ Params ^^^ for each item matching Connor
//TestIt.postEach(TestIt.eq(ref, "Connor"), "users/", Params)

//testing push
//TestIt.push("users/");    


//Test Create Class
var classname = "RavenClaw";
var classParams = {
    ClassID: 99,
    ClassName: classname
}


//uncomment to: create a class, delete class named RavenClaw, delete user from class and add user to class in that order
//TestIt.createClass(classname, classParams);
//TestIt.delClass("RavenClaw");
//TestIt.delUserInClass("cs177", "Connor");
//TestIt.addClassUser("cs177", "Connor");
