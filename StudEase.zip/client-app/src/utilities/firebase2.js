import Firebase from './firebase.js';
import Metadata from './metadata.js';
import chat from './firechat.js';

export default class Firebase2 {

	static getSession = function(roomId, callback) {
		var key = 'chat/room-metadata/' + roomId;
		setTimeout(function(){
			Firebase.ref(key).once('value').then(function(snapshot) {
				callback(null, snapshot.val());
			}, function(err) {
				callback(err, null);
			});
		}, 10);
	}

	static getCourse = function(courseId, callback) {
		var key = 'classes/' + courseId;
		setTimeout(function(){
			Firebase.ref(key).once('value').then(function(snapshot) {
				callback(null, snapshot.val());
			}, function(err) {
				callback(err, null);
			});
		}, 10);
	}

	/*	
	 *	Add / update file
	 *
	 *	fileId
	 *	(optional) courseId
	 *	(optional) sessionId
	 */
	static updateFile (params) {
		Firebase.ref('files').transaction(function(files) {
			try {
				if (!files[params.fileId]) {
					files[params.fileId] = {
						id: params.fileId,
						upvotes: 0,
					};
				}

				if (params.courseId) {
					if (!files[params.fileId]['classes']) {
						files[params.fileId]['classes'] = {};
					}
					files[params.fileId]['classes'][params.courseId] = true;
				}

				if (params.sessionId) {
					if (!files[params.fileId]['sessions']) {
						files[params.fileId]['sessions'] = {}
					}
					files[params.fileId]['sessions'][params.sessionId] = true;
				}

			} catch (e) {}
			return files;
		});

		if (params.courseId) {
			// Add file to class
			Firebase.ref('classes/' + params.courseId).transaction(function(course) {
				try {
					if (course) {
						if (!course['files']) {
							course['files'] = {};
						}
						course['files'][params.fileId] = true;
					}
				} catch (e) {}
				return course;
			});
		}

		if (params.sessionId) {
			// Add file to session
			Firebase.ref('chat/room-metadata/' + params.sessionId).transaction(function(session) {
				try {
					if (session) {
						if (!session['files']) {
							session['files'] = {};
						}
						session['files'][params.fileId] = true;
					}
				} catch (e) {}
				return session;
			});
		}
	}

	/*	
	 *	Add session
	 *
	 *	name
	 *	(optional) courseId
	 */
	static addSession (params, callback) {
		chat.createRoom(params.name, 'public', function(roomId) {
			chat.enterRoom(roomId);
			if (params.courseId) {
				Firebase.ref('classes/' + params.courseId).transaction(function(course) {
					try {
						if (course) {
							if (!course['sessions']) {
								course['sessions'] = {};
							}
							course['sessions'][roomId] = true;
						}
					} catch (e) {
						if (callback) { callback(e, null); }
					}
					if (callback) { callback(null, roomId) };
					return course;
				});
			}
		});
	}

	/*	
	 *	Enter class' chat room
	 *
	 *	courseId
	 */
	static enterClass (params) {
		Firebase.ref('classes/' + params.courseId).once('value').then(function(snapshot) {
			var course = snapshot.val();
			if (course && !course['chatRoomId']) {
				chat.createRoom(params.courseId, 'public', function(roomId) {
					Firebase.ref('classes/' + params.courseId).transaction(function(course) {
						try {
							if (course) {
								if (!course['chatRoomId']) {
									course['chatRoomId'] = roomId;
								} else {
									chat.leaveRoom(roomId);
								}
								chat.enterRoom(course['chatRoomId']);
							}
						} catch (e) {}
						return course;
					});
				});
			} else if (course) {
				chat.enterRoom(course['chatRoomId']);
				/*for (var sessionId in course['sessions']) {
					chat.enterRoom(sessionId.toString());
				}*/
			}
		}, function(err) {
			// swallow error, do nothing
		});
	}

	/*	
	 *	Enter session's chat room
	 *
	 *	courseId
	 *	sessionId
	 */
	static enterSession (params) {
		Firebase.ref('classes/' + params.courseId).once('value').then(function(snapshot) {
			var course = snapshot.val();
			if (course) {
				chat.enterRoom (params.sessionId);
			}
		}, function(err) {
			// swallow error, do nothing
		});
	}

	/*	
	 *	courseId
	 */
	static listenToClassFiles (params, callback) {
		Firebase2._listenFileList (Firebase.ref('classes/' + params.courseId + '/files'), callback);
	}

	/*	
	 *	sessionId
	 */
	static listenToSessionFiles (params, callback) {
		Firebase2._listenFileList (Firebase.ref('chat/room-metadata/' + params.sessionId + '/files'), callback);
	}

	/*	
	 *	Helper to listen to a list of files given a ref pointing to a list of files
	 */
	static _listenFileList (ref, callback) {
		var filesBeingListenedTo = {}; // Set of fileIds
		var driveDataCache = {}; // Map of fileId -> drive meta data
		var dbDataCache = {}; // Map of fileId -> db data (upvotes / tags)
		var fileCache = {}; // Map of fileId -> complete file info

		var onFileChanged = function(fileId, onComplete) {
			if (!driveDataCache[fileId]) {
				Metadata.getFileMetadata(fileId, function(err, data) {
					if (!err && data) {
						driveDataCache[fileId] = data;
						onComplete();
					}
				});
			} else {
				onComplete();
			}
		}

		ref.on('value', function(snapshot) {
			var fileIds = snapshot.val() || {};
			for (var fileId in fileIds) {
				if (!filesBeingListenedTo[fileId]) {
					filesBeingListenedTo[fileId] = true;
					Firebase.ref('files/' + fileId).on('value', function(snapshot) {
						var file = snapshot.val();
						if (file) {
							dbDataCache[fileId] = file;
							onFileChanged(fileId, function() {
								fileCache[fileId] = Object.assign(
									driveDataCache[fileId],
									dbDataCache[fileId],
									{ id: fileId }
								);
								callback(fileCache);
							});
						}
					});
				}
			}
		});
	}


}