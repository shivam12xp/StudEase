import firebase from 'firebase';
import googleAPI from './googleapi.js';

// Init firebase
var config = {
	apiKey: 'AIzaSyBr-IXwMx8ngZeZxLXZ3k4EenfogoS3m_0',
	authDomain: 'citrix-capstone-2016.firebaseapp.com',
	databaseURL: 'https://citrix-capstone-2016.firebaseio.com',
	storageBucket: 'citrix-capstone-2016.appspot.com',
	messagingSenderId: '827618240582'
};
firebase.initializeApp(config);

var _chat;

var token;

export default class Firebase {

	static openAuthPopup(chat, peerVideo, callback) {
		_chat = chat;
		var provider = new firebase.auth.GoogleAuthProvider();
		provider.addScope('https://www.googleapis.com/auth/plus.login');
		provider.addScope('https://www.googleapis.com/auth/drive');

		return firebase.auth().signInWithPopup(provider).then(function(result) {
			token = result.credential.accessToken;
			var googleUser = result.user;
			console.log(token);
			console.log('Signing in', googleUser);
                        
                        Firebase.addPhoto(googleUser.uid, googleUser.photoURL, function(err, photo){
                                if(!err){
                                 } else{
                                     
                                 }
                                 });
                                 
			// Set the firechat user and resume prior sessions if they are stored
			chat.setUser(googleUser.uid, googleUser.displayName, function(user) {
				chat.user = user;
				console.log('Initializing peer video');
				peerVideo.init(user.id, function(err, id) {
					if (err) {
						console.log('Failed to init peer video');
						callback(err, null);
					} else {
						console.log('Initialized peer video');
						callback(null, id);
					}
				});
			});
			// Initialize GAPI
			googleAPI.init(token);
		}).catch(function(err) {
			console.log(err);
			callback(err, null);
		});
	}

	static ref(key) {
		return firebase.database().ref(key);
	}

	static getOAuth() {
		return token;
	}


	// All callbacks are functions which take (error, data)


	/* Getters */

        static getActiveSessions = function(courseId, callback){
            var key = 'classes/' + courseId + '/activeSessions';
            Firebase.ref(key).once('value').then(function(snapshot) {
				callback(null, Object.keys(snapshot.val()));
			}, function(err) {
				callback(err, null);
			});
        }
        static getClassFiles = function(courseId, callback){
            var key = 'classes/' + courseId + '/files';
              Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, Object.keys(snapshot.val()));
		}, function(err) {
			callback(err, null);
		});
        }
        static getClassActives = function(courseId, callback){
            var key = 'classes/' + courseId + '/actives';
              Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, Object.keys(snapshot.val()));
		}, function(err) {
			callback(err, null);
		});
        }
        static getSessCreator = function(sessId, callback){
            var key = 'chat/room-metadata/' + sessId + '/createdByUserId';
            Firebase.ref(key).once('value').then(function(snapshot){
                callback(null, snapshot.val());
            }, function(err){
               callback(err, null); 
            });
        }
        static getSessName = function(sessId, callback){
            var key = 'chat/room-metadata/' + sessId + '/name'
            Firebase.ref(key).once('value').then(function(snapshot){
                callback(null, snapshot.val());
            }, function(err){
               callback(err, null); 
            });
        }
        static getActiveUser = function(classId, uid, callback){
            var  key = 'classes/' + classId + '/actives/' + uid;
            Firebase.ref(key).once('value').then(function(snapshot){
                callback(null, snapshot.val());
            }, function(err){
               callback(err, null); 
            });
        };
        
         static getSessActives = function(sessId, callback){
            
             var key = 'chat/room-metadata/' + sessId + '/actives';
              Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, Object.keys(snapshot.val()));
		}, function(err) {
			callback(err, null);
		});
         };
        
        static getPhoto = function(uid, callback){
            var key = 'chat/users/' + uid + '/photo';
            Firebase.ref(key).once('value').then(function(snapshot){
                callback(null, snapshot.val());
            }, function(err){
               callback(err, null); 
            });
        };
        
	static getUser = function(userId, callback) {
		var key = 'chat/users/' + userId;
		Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, snapshot.val());
		}, function(err) {
			callback(err, null);
		});
	};
        
        static getUserName = function(userId, callback) {
		var key = 'chat/users/' + userId + '/name';
		Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, snapshot.val());
		}, function(err) {
			callback(err, null);
		});
	};

	static getClass = function(classId, callback) {
		var key = 'classes/' + classId;
		Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, snapshot.val());
		}, function(err) {
			callback(err, null);
		});
	};
        
        static getSessionsFromClass = function(classId, callback){
            var key = 'classes/' + classId + '/sessions';
            Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, Object.keys(snapshot.val()));
		}, function(err) {
			callback(err, null);
		});
        };
        
        static getSessionFromClass = function(classId, sessId, callback){
            var key = 'classes/' + classId + '/sessions/' + sessId;
            Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, snapshot.val());
		}, function(err) {
			callback(err, null);
		});
        };
        

	static getFile = function(fileId, callback) {
		var key = 'files/' + fileId;
		Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, snapshot.val());
		}, function(err) {
			callback(err, null);
		});
	};

	static getClassFileIds = function(classId, callback) {
		var key = 'classes/' + classId + '/files';
		Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, Object.keys(snapshot.val()));
		}, function(err) {
			callback(err, null);
		});
	};
  	static getSessFileIds = function(sessId, callback) {
		var key = 'chat/room-metadata/' + sessId + '/files';
		Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, Object.keys(snapshot.val()));
		}, function(err) {
			callback(err, null);
		});
	};
        
    static getSessionsInUser = function(userId, callback){
        var key = 'chat/users/' + userId + '/rooms';
        Firebase.ref(key).once('value').then(function(snapshot){
           callback(null, Object.keys(snapshot.val()));
       }, function(err){
           callback(err, null);
        });
    };

    static getUserInClass = function(classId, userId, callback){
        var key = 'classes/' + classId + '/users/' + userId;
        Firebase.ref(key).once('value').then(function(snapshot){
           callback(null, snapshot.val());
       }, function(err){
           callback(err, null);
        });
    };
    static getUsersInClass = function(classId, callback){
        var key = 'classes/' + classId + '/users';
        Firebase.ref(key).once('value').then(function(snapshot){
           callback(null, Object.keys(snapshot.val()));
       }, function(err){
           callback(err, null);
        });
    };
    
    static getClassInUser = function(userId, classId, callback){
        var key = 'chat/users/' + userId + '/classes/' + classId;
        Firebase.ref(key).once('value').then(function(snapshot){
           callback(null, snapshot.val());
       }, function(err){
           callback(err, null);
        });
    };
    
    static getActiveUser = function(name, callback){
        var key = 'chat/user-names-online/' + name;
        Firebase.ref(key).once('value').then(function(snapshot){
           callback(null, snapshot.val());
       }, function(err){
           callback(err, null);
        });
    };
    


	/* Setters / mutators / deletion */

	// Add class IFF it does not already exist
	static addClass = function(classId, callback) {
		// new class to add 
		var theClass = {
			'id': classId,
		};
		Firebase.ref('classes').transaction(function(classes){
			try {
				if (classes) {
					if (!classes[classId]) {
						classes[classId] = theClass;					
					}
				}
			} catch (e) { if (callback) callback(e, null); }
			if (callback) callback (null, classes[classId]);
			return classes;
		});
	}

	// Add file if it does not already exists
	// If it already exists, add it to the given class
	static addFile = function(fileId, classId, callback) {
		Firebase.ref('files').transaction(function(files){
			try {
				// new file to add
				var file = {
					'id': fileId,
					'upvotes': 0,
					'classes': {},
					'sessions': {},
					'tags': []
				};
				file['classes'][classId] = true;
				if (files) {
					// files table exists - add to it
					if (!files[fileId]) {
						files[fileId] = file;
					} else {
						if (!files[fileId]['classes']) {
							files[fileId]['classes'] = {};
						}
						files[fileId]['classes'][classId] = true;
					}
					callback(null, files[fileId]);
				}
			} catch (e) { callback(e, null); }
			return files;
		});
		// Add file to class table
		Firebase.ref('classes/' + classId).transaction(function(theClass){
			try {
				if (theClass) {
					if (!theClass['files']) {
						theClass['files'] = {};
					}
					theClass['files'][fileId] = true;
				}
			} catch (e) { callback(e, null); }
			return theClass;
		});
	}

	// Add user to class
	static addUserToClass = function(userId, classId, callback) {
		Firebase.ref('chat/users/' + userId).transaction(function(user){
			try {
				if (user) {
					if (!user['classes']) {
						user['classes'] = {};
					}
					user['classes'][classId] = true;
					callback(null, user['classes']);
				}
			} catch (e) { callback(e, null); }
			return user;
		});
		// Add file to class table
		Firebase.ref('classes/' + classId).transaction(function(theClass){
			try {
				if (theClass) {
					if (!theClass['users']) {
						theClass['users'] = {};
					}
					theClass['users'][userId] = true;
				}
			} catch (e) { callback(e, null); }
			return theClass;
		});
	}
        
        static addNameToClass = function(name, classId, callback){
            Firebase.ref('classes/' + classId).transaction(function(theClass){
			try {
                                if (theClass){
                                        if(!theClass[ 'names' ]){
                                            theClass['names'] = {};
                                        }
                                        theClass['names'][name] = true;
                                }
			} catch (e) { callback(e, null); }
			return theClass;
		});
        }

	//Add List of Files to Session
    static addFileToSession = function(fileId, sessId, callback) {
    	var ready = false;
		// Add file to class table
		Firebase.ref('chat/room-metadata/' + sessId).transaction(function(theSess){
			try {
				if (theSess) {
					if (!theSess['files']) {
						theSess['files'] = {};
					}
					theSess['files'][fileId] = true;
					if (ready) {
						callback(null, theSess['files'][fileId]);
					} else {
						ready = true;
					}
				}
			} catch (e) { callback(e, null); }
			return theSess;
		});
		// Add sessId to file
		Firebase.ref('files/' + fileId).transaction(function(file){
			try {
				if (file) {
					if (!file['sessions']) {
						file['sessions'] = {};
					}
					file['sessions'][sessId] = true;
					if (ready) {
						callback(null, file);
					} else {
						ready = true;
					}
				}
			} catch (e) { callback(e, null); }
			return file;
		});
	}
        
    static addSessionToClass = function(sessId, classId, callback) {
		// Add file to class table
		Firebase.ref('classes/' + classId).transaction(function(theClass){
			try {
				if (theClass) {
					if (!theClass['sessions']) {
						theClass['sessions'] = {};
					}
					theClass['sessions'][sessId] = true;
				}
			} catch (e) { if (callback) { callback(e, null); } }
			if (callback) { callback(null, theClass) };
			console.log('class', theClass);
			return theClass;
		});
	}

	// add tag to file
	static addTagToFile = function(fileId, tag, callback){
		var key = 'files/' + fileId;
		Firebase.ref(key).transaction(function(file) {
			try{
				if (file) {
					if (!file['tags']) {
						file['tags'] = {};
						//file['tags'] = tag;
					}
					file['tags'][tag] = true;
					callback(null, file['tags']);
				}
			} catch (e) { callback(e, null); }
			return file;
		});
	}

	//get tags from file
	static getTags = function(fileId, callback) {
		var key = 'files/' + fileId + '/tags';
		Firebase.ref(key).once('value').then(function(snapshot) {
			callback(null, snapshot.val());
		}, function(err) {
			callback(err, null);
		});
	};

	static removeTag = function(fileId, tag) {
		console.log("removed");
		Firebase.ref('files/' + fileId + '/tags/' + tag).remove();
	};
        
	// toggle upvote on file
	static toggleUpvote = function(fileId, callback) {
		var userId = _chat.user.id;
		var key = 'files/' + fileId;
		Firebase.ref(key).transaction(function(file) {
			try {
				if (file) {
					if (!file['upvoters']) {
						file['upvoters'] = {};
					}
					if (file['upvoters'][userId]) {
						delete file['upvoters'][userId];
						file['upvotes'] -= 1;
					} else {
						file['upvoters'][userId] = true;
						file['upvotes'] += 1;
					}
					callback (null, file['upvotes']);
				}
			} catch (e) { callback(e, null); }
			return file;
		});
	}

	static removeUserFromClass = function(userId, classId) {
		Firebase.ref('chat/users/' + userId + '/classes/' + classId).remove();
		Firebase.ref('classes/' + classId + '/users/' + userId).remove();
	};

	static removeClass = function(classId) {
		Firebase.getClass(classId, function(err, theClass) {
			if (!err && theClass) {
				if (theClass['users']) {
					Object.keys(theClass['users']).forEach(function(userId) {
						Firebase.ref('chat/users/' + userId + '/classes/' + classId).remove();
					});
				}
				if (theClass['files']) {
					Object.keys(theClass['files']).forEach(function(fileId) {
						Firebase.ref('files/' + fileId + '/classes/' + classId).remove();
					});
				}
				Firebase.ref('classes/' + classId).remove();
			}
		});
	}

	static removeFile = function(fileId) {
		Firebase.getFile(fileId, function(err, file) {
			if (!err && file) {
				if (file['classes']) {
					Object.keys(file['classes']).forEach(function(classId) {
						Firebase.ref('classes/' + classId + '/files/' + fileId).remove();
					});
				}
				Firebase.ref('files/' + fileId).remove();
			}
		});
	}
        
        static addPhoto = function(uid, photoURL, callback){
            var key = 'chat/users/' + uid;
            Firebase.ref(key).transaction(function(user){
                            try {
                                    if (user){
                                            if(!user['photo']){
                                                    user['photo'] = {};
                                            }
                                            user['photo'] = photoURL;
                                            callback(null, user['photo']);
                                        }
                            } catch (e) { callback(e, null); }
                            return user;
                        });
        }
        
        static enterClass = function(classId, userId, callback){
            var key = 'classes/' + classId;
            Firebase.ref(key).transaction(function(Class){
                    try{
                        if(Class){
                            if(!Class['actives']){
                                Class['actives'] = {};
                            }
                            Class['actives'][userId] = true;
                            callback(null, Class['actives']);
                        }
                    }catch(e){callback(e, null);}
                    return Class;
            });
        }
        
        static leaveClass = function(classId, userId){
           var  key = 'classes/' + classId + '/actives/' + userId;
           Firebase.ref(key).remove();
        }
        
        
        static enterSess = function(sessId, userId, callback){
            var key = 'chat/room-metadata/' + sessId;
            Firebase.ref(key).transaction(function(Sess){
                    try{
                        if(Sess){
                            if(!Sess['actives']){
                                Sess['actives'] = {};
                            }
                            Sess['actives'][userId] = true;
                            
                            callback(null, Sess['actives']);
                        }
                    }catch(e){callback(e, null);}
                    return Sess;
            });
        }
        
        static leaveSess = function(sessId, userId){
           var key = 'chat/room-metadata/' + sessId + '/actives/' + userId;
           Firebase.ref(key).remove();
        }

}
