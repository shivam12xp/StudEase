
var gapi;
if (self.gapi) {
	gapi = self.gapi;
} else {
	self.onload = function() {
		gapi = self.gapi;
	}
}

export default class googleAPI {

	static init(token) {
		gapi.load('client', function() {
			gapi.auth.setToken({
			    access_token: token
			});
			gapi.load('client', function() {
				gapi.client.load('drive', 'v2', function(){
				});
				gapi.client.load('drive', 'v3', function(){
				});
			});
		});
	}

	static getContentPlainText(fileId, callback) {
		gapi.client.drive.files.export({
			'fileId' : fileId,
			'mimeType' : 'text/plain'
		}).then(function(success){
			callback('' + success.body);   
		}, function(fail){
			console.log('Error '+ fail.result.error.message);
		})
	}

	static createFolder(folderName) {
		console.log("create folder", gapi.client.drive);
		var body = {
			'title': folderName,
			'mimeType': "application/vnd.google-apps.folder"
		};
		var request = gapi.client.drive.files.insert({
			'resource': body
		});
		request.execute(function(resp) {
			console.log('Folder ID: ' + resp.id);
		});
	}

	static retrieveRevisions(fileId, callback) {
		var request = gapi.client.drive.revisions.list({
			'fileId': fileId
	  	});
		request.execute(callback);
	}

	static retrieveRevisionData(fileId, revisionId) {
  		var request = gapi.client.drive.revisions.get({
	    	'fileId': fileId,
	    	'revisionId': revisionId
	  	});
	  	request.execute(function(resp) {
	    	console.log('Revision ID: ' + resp.id);
	    	console.log('Modified Date: ' + resp.modifiedDate);
		    if (resp.pinned) {
		      console.log('This revision is pinned');
	    	}
	  	});
	}
}