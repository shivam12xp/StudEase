
var titleWeight = 10.0;
var tagWeight = 0.02; //was .01
var partialFactor = 0.005; // how highly do we weight 'arti' in 'partial'
var upvoteWeight = .02; //was 3

export default class searchScore {
	static assignSearchValue(files, searchString) {
		var maxUpvotes = 0; //added
		for(var h = 0; h < files.length; h++){ //added
     			 if (files[h].upvotes > maxUpvotes){
      			   maxUpvotes = files[h].upvotes;
      			}
  	  	}
		for(var i = 0; i < files.length; i++) {
			var file = files[i];
			var upvoteRatio = 0;
			if (!file || !file.name) { continue; }

			if (files[i].upvotes > 0){
				upvoteRatio = (files[i].upvotes)/maxUpvotes; 
			}

			var tagScore = 0;
			var titleScore = 0;
			var upvoteScore = upvoteRatio*upvoteWeight;

			var searchTokens = searchString.split(' ');
			var fileTokens = file.name.split(' ');

			for(var j = 0; j < searchTokens.length; j++) {
				var searchToken = searchTokens[j].toLowerCase();

				for(var k = 0; k < fileTokens.length; k++){
					var fileToken = fileTokens[k].toLowerCase();
					if(searchToken === fileToken){
						titleScore += titleWeight;
					} else if (searchToken.includes(fileToken) && fileToken.length > 0) {
						titleScore += titleWeight * partialFactor;
					} else if (fileToken.includes(searchToken) && searchToken.length > 0) {
						titleScore += titleWeight * partialFactor;
					}
				}

				if (file.tags) {
					for (var tagToken in file.tags) {
						if(searchToken === tagToken){
							tagScore += tagWeight;
						} else if (searchToken.includes(tagToken) && tagToken.length > 0) {
							console.log(file.name, "partial", tagToken, searchToken);
							tagScore += tagWeight * partialFactor;
						} else if (tagToken.includes(searchToken) && searchToken.length > 0) {
							console.log(file.name, "partial", tagToken, searchToken);
							tagScore += tagWeight * partialFactor;
						}
					}
				}
			}

			file.score = tagScore + titleScore;
			if (file.score > 0.00001) {
				file.score += upvoteScore;
			}
			console.log(file.name, file.score, tagScore, titleScore, upvoteScore);
		} 

	}

}
