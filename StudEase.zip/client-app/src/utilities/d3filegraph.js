import docs from '../../public/docs.png';
import slides from '../../public/slides.png';
import sheets from '../../public/sheets.png';


function getRandomInt(min, max) {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min)) + min;
}

var imgUrls = [
	docs, slides, sheets
];

var d3 = null;

export default class D3FileGraph {

	static Generate(parentSelector) {

		// Wrapped in function so we can wait till d3 loads
		var doGenerate = function() {

			var links = [];
			for (var i = 0; i < 200; i++) {
				links.push({
					source: i,
					target: Math.abs(getRandomInt(i - 6, i + 6)),
				});
			}

			var nodes = {};

			// Compute the distinct nodes from the links.
			links.forEach(function(link) {
				link.source = nodes[link.source] || (nodes[link.source] = {name: link.source});
				link.target = nodes[link.target] || (nodes[link.target] = {name: link.target});
			});

			var force = d3.layout.force()
				.nodes(d3.values(nodes))
				.links(links)
				.size([window.innerWidth + 600, window.innerHeight + 600])
				.linkDistance(function(){ return getRandomInt(50, 300); })
				.charge(-300)
				.friction(0.8)
				.on("tick", tick)
				.start();

			var svg = d3.select(parentSelector).append("svg")
				.attr("width", window.innerWidth + 600)
				.attr("height", window.innerHeight + 600)
				.attr("style", "margin-left: -300px; margin-top: -300px")

			var link = svg.selectAll(".link")
				.data(force.links())
				.enter().append("line")
				.attr("class", "link");
					
			var node = svg.selectAll(".node")
				.data(force.nodes())
				.enter().append("g")
				.attr("class", "node")
				.call(force.drag);
					
			node.append("image")
				.attr("class", "node")
				.attr("xlink:href", function(d) {
					d.size = getRandomInt(10, 40); // compute random size
					return imgUrls[getRandomInt(0, imgUrls.length)];
				})
				.attr("x", function(d) { return (-0.5 * d.size) + "px"; })
				.attr("y", function(d) { return (-0.5 * d.size) + "px"; })
				.attr("width", function(d) { return d.size + "px"; })
				.attr("height", function(d) { return d.size + "px"; });

			var safety = 0;
			while(force.alpha() > 0.05) { // You'll want to try out different, "small" values for this
			    force.tick();
			    if(safety++ > 500) {
			      break;// Avoids infinite looping in case this solution was a bad idea
			    }
			}

			function tick() {
				link
					.attr("x1", function(d) { return d.source.x; })
					.attr("y1", function(d) { return d.source.y; })
					.attr("x2", function(d) { return d.target.x; })
					.attr("y2", function(d) { return d.target.y; })
					.attr("stroke", "whitesmoke")
					.attr("stroke-opacity", "0.4")
					.attr("stroke-width", "1");
				node
					.attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; });
			}
		}

		// Wait for d3 to load

		if (self.d3) {
			d3 = self.d3;
			doGenerate();
		} else {
			self.onload = function() {
				d3 = self.d3;
				doGenerate();
			}
		}

	}
}
