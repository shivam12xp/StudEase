import request from 'request';
import Firebase from './firebase.js';

var filecache = {};
/*
try {
	filecache = JSON.parse(localStorage.getItem('filecache')) || {};
	console.log("loaded filecache from localstorage: ", filecache);
} catch (e) {
	filecache = {};
}
*/


export default class Metadata {
	static getFileMetadata (fileId, callback, retries) {
		// Default to N retries
		if (retries !== 0 && !retries) {
			retries = 30;
		}
		
		if (retries <= 0){
			callback('failed to get data');
			return;
		}

		if (filecache[fileId]){
			var data = filecache[fileId];
			callback(null, data);
			//return;
		}

		request({
				url: 'https://www.googleapis.com/drive/v2/files/' + fileId,
				headers:
					{ 'Authorization' : 'Bearer ' + Firebase.getOAuth()}
				//headers: headers,
		}, function (error, response, body){
			if (!error) {
				body = JSON.parse(body);
				if (body && body.title && body.alternateLink && body.mimeType && body.modifiedDate) {
					
					var data = {
						name: body.title,
						url: body.alternateLink,
						theme: body.mimeType, // TODO
						tags: [], // TODO
						modified: body.modifiedDate
					}

					filecache[fileId] = data;
					localStorage.setItem('filecache', JSON.stringify(filecache));
								
					callback(error, data);
				} else {
					Metadata.getFileMetadata(fileId, callback, retries-1);
					callback(error, null);
				}
			}
			 else {
				if (retries > 0){
					Metadata.getFileMetadata(fileId, callback, retries-1);
				}
				else {
					callback(error, null);
				}
			}
		});

	} 

}
