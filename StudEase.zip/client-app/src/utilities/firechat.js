import 'firechat';
import Firebase from './firebase.js';

var chatMessages = {};
var chatComponents = {}; // Map of room ID to ChatComponent instances

// https://firechat.firebaseapp.com/docs/#api
function firechatInit(chat) {
	
	chat.mountComponent = function(roomId, chatComponent) {
		chatComponents[roomId] = chatComponent;
		chatComponents[roomId].onMessagesUpdated(chatMessages[roomId]||[]);
	};

	chat.unmountComponent = function(roomId, chatComponent) {
		if (chatComponents[roomId] === chatComponent) {
			delete chatComponents[roomId];
		}
	};

	chat.on('room-enter', function(data) {
		console.log(data);
	});

	chat.on('room-exit', function(data) {
		console.log(data);
	});

	chat.on('message-add', function(roomId, message) {
		chatMessages[roomId] = (chatMessages[roomId] || []).concat(message);
		if (chatComponents[roomId]) {
			chatComponents[roomId].onMessagesUpdated(chatMessages[roomId]);

		}
	});

	chat.on('message-remove', function(data) {
		console.log(data);
	});

	chat.on('room-invite', function(data) {
		console.log(data);
	});

	chat.on('room-invite-response', function(data) {
		console.log(data);
	});

	return chat;
}

// Init firechat
var chat;
var chatRef = Firebase.ref('chat');
var chatInit = function() {
	chat = firechatInit(new self.Firechat(chatRef));
}
if (self.Firechat) {
	chatInit();
} else {
	self.onload = function() {
		chatInit();
	}
}

export default chat;