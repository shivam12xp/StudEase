import request from 'request';
import Firebase from './firebase.js';

// var fileMetadata = {
//   'title' : 'StudEase',
//   'mimeType' : 'application/vnd.google-apps.folder' // if it's a folder
// };

export default class NewFile {
  static createNewFile (fileMetadata, callback) {
    request({
        method: 'POST',
        url: 'https://www.googleapis.com/upload/drive/v2/files',
        params: {'uploadType': 'multipart'},
        headers: { 'Authorization' : 'Bearer ' + Firebase.getOAuth(),
        //           'Content-Type' : 'application/json' },
                  'Content-Type' : 'multipart/related' },
        // body: fileMetadata
        preambleCRLF: true,
        postambleCRLF: true,
        multipart: [
          {
            'Content-Type' : 'application/json',
            body: fileMetadata
          },
          {
            'Content-Type' : 'application/vnd.google-apps.folder'
          }
        ]
    }, function (error, response, body){
      if (!error) {
        console.log(body);
        body = JSON.parse(body);
        var id = body.id;
        console.log(id);
        callback(error, id);
      }
    });
  }
}
