import request from 'request';

class Server {
	static get(relUrl, headers, body, callback) {
		request({
		    url: Server.getServerUrl() + relUrl,
		    method: 'GET',
		    headers: headers,
		}, function(error, response, body){
		    callback(error, response, body);
		});
	}

	static post(relUrl, headers, body, callback) {
		request({
		    url: Server.getServerUrl() + relUrl,
		    method: 'POST',
		    headers: headers,
		}, function(error, response, body){
		    callback(error, response, body);
		});
	}

	static getServerUrl(includePort = true) {
		return process.env.NODE_ENV === 'production'
			//? 'server-92837.onmodulus.net'
			//? 'studytogether-95814.app.xervo.io'
			? 'citrixcapstone-96514.app.xervo.io'
			: 'localhost' + (includePort ? (':' + 8080) : '');
	}

	static getServerPort() {
		return process.env.NODE_ENV === 'production' ? 443 : 8080;
		//return 8080;
	}

	static getClientUrl(){
		return process.env.NODE_ENV === 'production'
			? 'https://citrix-capstone-2016.firebaseapp.com'
			: 'http://localhost' + ':' + 3000;
	}
}

export default Server;