import Peer from 'peerjs';

import chat from '../utilities/firechat.js';
import Firebase from './firebase.js';
import Server from './server.js';

var peer;		// Local peer
var localStream;// Local audio/video stream to send to peers
var calls;		// Map of peer IDs to active calls
var listeners;	// Map of room IDs to components listening for calls' on('stream') events

// Verify that the call is coming from a user we want to be calling
var shouldAcceptCall = function(call) {
	return true;
}

var handleCall = function(call) {
	// If we're already in a call with this peer, end the prior call
	if (calls[call.peer]) {
		calls[call.peer].close();
	}
	calls[call.peer] = call;
	// Allow other components to listen to the stream events
	call.on('stream', function(stream) {
		Object.values(listeners).forEach(function(listener) {
			listener.onStreamOpen(call.peer, stream);
		});
	});
	call.on('close', function() {
		Object.values(listeners).forEach(function(listener) {
			listener.onStreamClose(call.peer);
		});
	});
}

// Interface for external classes / components
export default class PeerVideo {

	static init(id, callback) {
		localStream = null;
		calls = {};
		listeners = {};

		peer = new Peer(id, {
			host: Server.getServerUrl(false),
			port: Server.getServerPort(),
			path: '/citrixapp',
			debug: 3
		});
		
		peer.on('open', function(id) {
			if (callback) {
	        	callback(null, id);
	        }
		});

		peer.on('call', function(call) {
			if (localStream && shouldAcceptCall(call)) {
				call.answer(localStream);
				handleCall(call);
			} else {
				console.log('Rejected call:', call);
			}
		});

		peer.on('error', function(err) {
			console.warn(err);
			if (callback) {
	        	callback(err, null);
	        }
		});
	}

	static initUserMedia(callback) {
		var videoSettings = {
			width: { max: 150 },
    		height: { max: 150 },
    		framerate: { max: 5 }
		}
		var attempts = [
			{audio: true, video: videoSettings},
			{audio: true, video: false},
			{audio: false, video: videoSettings}
		];
		var tryGetUserMedia = function() {
			if (attempts.length > 0) {
		      	navigator.mediaDevices.getUserMedia(attempts.shift()).then(function(stream) {
					localStream = stream;
					console.log(localStream, localStream.getTracks());
			        if (callback) { callback(localStream); }
				}).catch(function(err) {
					tryGetUserMedia();
				});
			} else { // Default to an empty stream
				localStream = new (window.MediaStream || window.webkitMediaStream)();
				if (callback) { callback(localStream); }
			}
		}
		tryGetUserMedia();
	}

	// Can't use this bc we don't have access to the stream (just the url object of it)
	static getStreamInfo(stream) {
		var info = {};
		stream.getTracks().forEach(function(track) {
			if (track.enabled && !track.muted) {
				info[track.kind] = true;
			}
		});
		return info;
	}

	static _stopUserMedia(kind = null) {
		if (localStream) {
			localStream.getTracks().forEach(function(track) {
				if (!kind || track.kind === kind) {
					track.stop();
				}
			});
		}
	}

	// Updates: kind -> true/false mapping
	// ex: { audio: true, video: false }
	static updateUserMedia(updates) {
		if (localStream) {
			var keys = Object.keys(updates);
			localStream.getTracks().forEach(function(track) {
				if (keys.includes(track.kind)) {
					track.enabled = updates[track.kind];
				}
			});
		}
	}

	static getLocalStream() {
		return localStream;
	}

	static call(userId) {
		if (userId !== chat.user.id) {
			handleCall(peer.call(userId, localStream));
		}
	}

	static mountListener(roomId, component) {
		listeners[roomId] = component;
		PeerVideo._updateUsersForRoom(roomId);
		// Listen for users entering / leaving chat
		var key = 'chat/room-users/' + roomId;
		Firebase.ref(key).on('value', function(snapshot) {
			if (listeners[roomId]) {
			    PeerVideo._updateUsersForRoom(roomId);
			}
		});
	}

	static unmountListener(roomId, component) {
		if (listeners[roomId] === component) {
			delete listeners[roomId];
		}
		if (Object.keys(listeners).length <= 0) {
			PeerVideo._stopUserMedia();
			calls = {};
		}
	}

	static onUsersUpdate(roomId, userIds) {
		if (listeners[roomId]) {
			listeners[roomId].onUsersUpdate(userIds);
		}
	}

	static _updateUsersForRoom(roomId) {
		const limit = 1000;
		chat.getUsersByRoom(roomId, limit, function(users) {
			PeerVideo.onUsersUpdate(roomId, Object.keys(users));
		});
	}

}