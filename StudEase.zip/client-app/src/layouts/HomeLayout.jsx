import React, { Component } from 'react';
import PeerVideo from '../utilities/peerVideo.js';
import chat from '../utilities/firechat.js';
import Firebase from '../utilities/firebase.js';
import D3FileGraph from '../utilities/d3filegraph.js';
import BaseLayout from './BaseLayout.jsx';
import ChatComponent from '../components/ChatComponent.jsx';
import logo from '../../public/logo.png'

import '../../public/css/HomeLayout.css';

class HomeLayout extends Component {

	componentWillMount() {
		if (chat.user) {
			this.onLogin();
		}
		BaseLayout.update({
			displayHomeButton: false,
			displayHeader: false
		});
	}

	componentDidMount() {
		D3FileGraph.Generate('.home-layout');
	}

	handleClickLogin = () => {
		var self = this;
		Firebase.openAuthPopup(chat, PeerVideo, function(err, id) {
			console.log(err, 'Logged in as', id);
			if (!err) {
				self.onLogin();
			}
		});
	}

	onLogin = () => {
		this.context.router.push('/dashboard');
	}

	getMenuOptions = () => {
		return [
			{ icon: 'cog', content: 'TODO settings' },
			{ label: 'Chat', content: <ChatComponent roomId="-KVhUUhx-NWqQ-3CFM91"/> },
		];
	}

	render() {
		return (
			<div className='layout home-layout'>
				<div className='home-layout-overlay'/>
				<img className='logo' src={logo} alt="Logo" />
				<h2 className='welcome'>StudEase</h2>
				<div className='login-button-wrapper'>
					<button className='btn simplebutton login-button' onClick={ this.handleClickLogin }>
						Sign In
					</button>
				</div>
			
			</div>
		);
	}
}

// Add the react router to this' context so we can redirect to another route
HomeLayout.contextTypes = {
	router: React.PropTypes.object
};

export default HomeLayout;