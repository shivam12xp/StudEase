import React, { Component } from 'react';
import { Link } from 'react-router';
import { Glyphicon } from 'react-bootstrap';

import Firebase2 from '../utilities/firebase2.js';
import SidebarSlideComponent from '../components/SidebarSlideComponent.jsx';

import '../../public/css/BaseLayout.css';

var instances = {};

class BaseLayout extends Component {

	/*
	 * Params:
	 *	title: string
	 *	displayHomeButton: boolean (default true)
	 *	displayHeader: boolean (default true)
	 * 	menuOptions: array of objects of the form:
	 *		{ key, content, icon, label }
	 *		where either an icon or label is required but not both
	 *		icon will render an icon, label will render text label
	 */
	static update(params) {
		Object.values(instances).forEach(function(instance) {
			instance.update(params);
		});
	}

	constructor(props, context) {
		super(props, context);
		this.state = {
			currentKey: null,
			title: '',
			menuOptions: [],
			displayHomeButton: false,
			displayHeader: true,
			courseId: null, courseName: null,
			roomId: null, roomName: null,
		};
	}

	update = (params) => {
		var options = params.menuOptions || [],
			menu = this.refs.menu;
		this.setState({
			title: params.title,
			menuOptions: options,
			displayHomeButton: params.displayHomeButton !== false,
			displayHeader: params.displayHeader !== false,
			courseId: params.courseId,
			courseName: params.courseName || params.courseId,
			roomId: params.roomId,
			roomName: params.roomName || params.roomId,
		});
		// Close menu if the current menu key no longer exists
		if (menu) {
			var currKey = this.state.currentKey;
			if (currKey && !options.some(function(op) {
				if (op.key === currKey) {
					menu.show(op.content, op.key);
				}
				return op.key === currKey;
			})) {
				menu.hide();
			}
		}

		var self = this;
		Firebase2.getSession(params.roomId, function(err, session) {
			if (!err && session && session.name) {
				self.setState({ roomName: session.name });
			}
		});
		Firebase2.getCourse(params.courseId, function(err, course) {
			if (!err && course && course.title) {
				self.setState({ courseName: course.title });
			}
		});
	}

	componentWillMount() {
		instances[this] = this;
	}
	componentWillUnmount() {
		delete instances[this];
	}

	handleClickHome = () => {
		this.context.router.push('/dashboard');
	}

	handleClickCourse = () => {
		this.context.router.push('/course/' + this.state.courseId);
	}

	handleClickSession = () => {
		this.context.router.push('/course/' + this.state.courseId + '/session/' + this.state.roomId);
	}

	getMenuClickHandler = (option) => {
		var self = this;
		return function() {
			if (self.refs.menu) {
				self.setState({
					currentKey: self.refs.menu.toggle(option.content, option.key)
				});
			}
		}
	}

	getMenuButtons = () => {
		var self = this;
		if (!self.state.menuOptions) {
			return '';
		}
		return self.state.menuOptions.map(function(option, i) {
			if (option.icon) {
				var iconClassName = 'fa fa-' + option.icon
					+ ' header-option header-option-icon header-right'
					+ (option.key === self.state.currentKey ? ' active' : '');
				return (
					<i className={ iconClassName }
						key={ option.key }
						aria-hidden='true'
						onClick={ self.getMenuClickHandler(option) }
					/>
				);
			} else {
				var labelClassName = 'header-option header-option-text header-right'
					+ (option.key === self.state.currentKey ? ' active' : '');
				return (
					<div className={ labelClassName }
						key={ option.key }
						onClick={ self.getMenuClickHandler(option) }
						>
							{ option.label }
					</div>
				);
			}
		});
	}

	getBreadcrumbs = () => {
		if (this.state.displayHomeButton) {
			return (
				<div className='app-header-breadcrumbs'>
					<i className='fa fa-home header-option header-option-icon header-left'
						aria-hidden='true'
						onClick={ this.handleClickHome }
					/>
					{ this.getBreadcrumb_course() }
					{ this.getBreadcrumb_room() }
				</div>
			);
		} else {
			return '';
		}
	}
	getBreadcrumb_course = () => {
		if (this.state.courseId) {
			return (
				<div className='app-header-breadcrumb'>
					<span className='app-header-breadcrumb-spacer'>
						<Glyphicon glyph="chevron-right"/>
					</span>

					<span className='app-header-text-breadcrumb'>
						<Link to={ '/course/' + this.state.courseId }>
							{ this.state.courseName }
						</Link>
					</span>
				</div>
			);
		} else {
			return '';
		}
	}
	getBreadcrumb_room = () => {
		if (this.state.courseId && this.state.roomId) {
			return (
				<div className='app-header-breadcrumb'>
					<span className='app-header-breadcrumb-spacer'>
						<Glyphicon glyph="chevron-right"/>
					</span>
					<span className='app-header-text-breadcrumb'>
						<Link to={ '/course/' + this.state.courseId + '/session/' + this.state.roomId }>
							{ this.state.roomName }
						</Link>
					</span>
				</div>
			);
		} else {
			return '';
		}
	}

	render() {
		return (
			<div className='layout'>
				<div className={'app-header' + (this.state.displayHeader ? '' : ' hidden')}>
					{ this.getBreadcrumbs() }
					<div className='header-title'>{ this.state.title }</div>
					{ this.getMenuButtons() }
				</div>

				<div className={'app-body' + (this.state.displayHeader ? '' : ' fullheight')}>
					<div className='primary-pane'>
						{ this.props.children }
					</div>
					<SidebarSlideComponent ref='menu'/>
				</div>

			</div>
		);
	}

}

// Add the react router to this' context so we can redirect to another route
BaseLayout.contextTypes = {
	router: React.PropTypes.object
};

export default BaseLayout;