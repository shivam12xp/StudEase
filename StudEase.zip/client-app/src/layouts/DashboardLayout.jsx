import React, { Component } from 'react';
import { Link } from 'react-router';

import BaseLayout from './BaseLayout.jsx';
import BigCardComponent from '../components/BigCardComponent.jsx'
import CourseDashComponent from '../components/CourseDashComponent.jsx'
import Firebase from '../utilities/firebase.js';
import Firebase2 from '../utilities/firebase2.js';

import '../../public/css/DashboardLayout.css';



// todo get from db
var courseIds = ['cs-170', 'cs-189a', 'cs-181'];

export default class DashboardLayout extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {
			courses: {} // map of courseId -> course info object
		};
	}

	componentWillMount() {
		BaseLayout.update({
			//displayHeader: false,
		});
		courseIds.forEach((courseId) => {
			var self = this;
			Firebase.getClass (courseId, function(err, course){
				console.log(courseId, err, course);
				if (!err && course) {
					self.state.courses[courseId] = course;
					self.setState({});

					Firebase2.enterClass({
						courseId: courseId
					});
				}
			});
		});
	}


	render() {
		var self = this;
		
		var ids = Object.keys(self.state.courses);

		return (
			<div className='layout'>
			
				<div className='dash-courses'>
				{
					ids.map ((courseId, index) => {
						var course = self.state.courses[courseId];
						return (
							<div className='dash-course-card' key={ index }>
								<BigCardComponent theme='hidden'>
									<CourseDashComponent courseId={ courseId } course={ course }/>
								</BigCardComponent>
							</div>
						)
					})
				}
				</div>
			</div>
		);
	}

}
