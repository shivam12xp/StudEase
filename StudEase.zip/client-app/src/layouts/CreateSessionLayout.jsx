import React, { Component } from 'react';

export default class CreateSessionLayout extends Component {

	render() {
		return (
			<div>
				<h2>Create a session...</h2>				
			</div>
		);
	}

}