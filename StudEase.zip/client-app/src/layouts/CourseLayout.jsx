import React, { Component } from 'react';

import BigCardComponent from '../components/BigCardComponent.jsx';
import BigCardTabComponent from '../components/BigCardTabComponent.jsx';
import Metadata from '../utilities/metadata.js';
import Firebase from '../utilities/firebase.js';
import BaseLayout from './BaseLayout.jsx';

import HorzSlideComponent from '../components/HorzSlideComponent.jsx';
import VertSlideComponent from '../components/VertSlideComponent.jsx';

import ChatComponent from '../components/ChatComponent.jsx';
import SessionListComponent from '../components/SessionListComponent.jsx';
import ActiveUsersComponent from '../components/ActiveUsersComponent.jsx';
import '../../public/css/CourseLayout.css';
import chat from '../utilities/firechat.js';

import FileViewComponent from '../components/FileViewComponent.jsx';

class CourseLayout extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {
			title: '',
			description: '',
			chatRoomId: null,
		};
	}

	//enters and leaves in db
	componentWillMount() {
		var self = this;
		BaseLayout.update({
			title: '',
			displayHomeButton: true,
			courseId: self.props.params.courseId
		});
		Firebase.getClass (self.props.params.courseId, function(err, course){
			if (!err) {
				self.setState({
					title: course.title,
					description: course.description,
					chatRoomId: course.chatRoomId,
				});				
				self.enterIt(self.props.params.courseId);
			}else{
				console.log("Error");
			}
		});

		console.log("courselayout: courseID: " + this.props.params.courseId);
	}


		
	enterIt(courseID){
		var self = this;
		Firebase.enterClass(courseID, chat.user.id, function(err, user){
			if(!err){
				console.log("Good");	
			}else{
				console.log("Error");
			}
		});
	}

	onSessionSelected = (sessId) => {
        this.context.router.push('/course/' + this.props.params.courseId + '/session/' + sessId);
    }
	
	componentWillUnmount() {
		var self = this;
		Firebase.leaveClass(self.props.params.courseId, chat.user.id);
	}

		
	render() {
		return (
			<div className='layout'>
			
				<div className='course big-card-container'>
						<div className='course-summary'>
							<div className='course-summary-info-wrapper'>
								<div className='rounded-corners course-summary-info'>
									<h2 className='course-summary-info-title'>
										{ this.state.title }
									</h2>
									<div className='course-summary-info-description'>
										{ this.state.description }
									</div>
								</div>
							</div>

							{
								this.state.chatRoomId
								? (
									<div className='course-summary-users'>
										<BigCardComponent title='Messages'>
											<ChatComponent roomId={ this.state.chatRoomId }/>
										</BigCardComponent>
									</div>
								)
								: ('')
							}
						</div>
					

						<div className='course-sessions'>
							<div className='course-sessions-all'>
								<BigCardComponent title='Study Sessions'>
									<div className='course-sessions-list'>
										<SessionListComponent courseId={ this.props.params.courseId }
											onSessionSelected={ this.onSessionSelected }
										/>
									</div>
								</BigCardComponent>
							</div>
						</div>
					<div className='course-file-view'>
						<FileViewComponent courseId={ this.props.params.courseId } initialFileId={ this.props.params.fileId }
							inCourse={ true }/>
					</div>
				</div>

			
			</div>
		);
	}

}

CourseLayout.contextTypes = {
	router: React.PropTypes.object
};

export default CourseLayout;
