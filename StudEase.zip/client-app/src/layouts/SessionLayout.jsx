import React, { Component } from 'react';

import BigCardComponent from '../components/BigCardComponent.jsx';
import BigCardTabComponent from '../components/BigCardTabComponent.jsx';
import VidChatComponent from '../components/VidChatComponent.jsx';
import HorzSlideComponent from '../components/HorzSlideComponent.jsx';
import VertSlideComponent from '../components/VertSlideComponent.jsx';
import FileFrameComponent from '../components/FileFrameComponent.jsx';
import BaseLayout from './BaseLayout.jsx';
import '../../public/css/ChatComponent.css';

import ChatComponent from '../components/ChatComponent.jsx';

import FileListComponent from '../components/FileListComponent.jsx';
import chat from '../utilities/firechat.js';
import Firebase from '../utilities/firebase.js';
import Firebase2 from '../utilities/firebase2.js';

import FileViewComponent from '../components/FileViewComponent.jsx';

export default class SessionLayout extends Component {

	constructor(props, context) {
		super(props, context);
		this.state = {
			//file: null
		};
	}

//enters and leaves in db
	componentWillMount() {
		BaseLayout.update({
			title: '',
			displayHomeButton: true,
			courseId: this.props.params.courseId,
			roomId: this.props.params.roomId
		});
		
		Firebase.enterSess(this.props.params.roomId, chat.user.id, function(err, user){
			if(!err){
				
					console.log("Good");
					
					
			}else{
				console.log("Error");
			}
		});
		
				
		Firebase2.enterSession({
			sessionId: this.props.params.roomId,
			courseId: this.props.params.courseId,
		});
		
		var ref = Firebase.ref("chat/user-names-online/" + chat.user.id);
                var ref2 = Firebase.ref("chat/room-metadata/" + this.props.params.roomId + "/actives/" + chat.user.id);
                
                ref.onDisconnect().remove(function(err){
                    if(err){
                        console.log(err);
                    }
                });
                ref2.onDisconnect().remove(function(err){
                    if(err){
                        console.log(err);
                    }
                });
		
	}
		
		componentWillUnmount() {
				var self = this;
		Firebase.leaveSess(this.props.params.roomId, chat.user.id);
	}
	

	render() {
		return (
			<div className='layout'>
				<div className='big-card-container'>
					<HorzSlideComponent prefId='session-horz' default={ -0.25 }>
						<VertSlideComponent prefId='session-vert' default={ 0.15 }>
							<BigCardComponent title='Video Chat' theme='hidden'>
								<VidChatComponent roomId={ this.props.params.roomId }/>
							</BigCardComponent>
							<BigCardComponent title='Text Chat' theme='hidden'>
								<ChatComponent roomId={ this.props.params.roomId }/>
							</BigCardComponent>
						</VertSlideComponent>
						{
							<FileViewComponent roomId={ this.props.params.roomId } courseId={ this.props.params.courseId }
								inCourse={ false }/>
						}
					</HorzSlideComponent>
				</div>
			</div>
		);
	}

}
